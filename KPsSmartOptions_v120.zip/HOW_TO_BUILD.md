# KPsOptionsApk - KP's Options ka Android app (version 1.1.0 - License key ke saath)

Is zip se **KP's Options** (PC wala v9 Together) ka APK GitHub par banta hai. Ye naya, alag app hai:

| | |
|---|---|
| App ka naam | KP's Options |
| App ID | `com.kp.options` (KP's Algo / Multi / Pine / Auto ke saath ek hi phone me chal sakta hai) |
| Dashboard port | 5090 |
| Zip | `KPsOptionsApk_v110.zip` |
| Workflow file | `.github/workflows/kpsoptionsapk.yml` (naam: **Build KPsOptionsApk**) |
| GitHub repo (naya) | `KPsOptionsApk` |
| Banne wali APK | `KPs_Options.apk` (Release: **KPsOptionsApk build N**) |

## GitHub par APK banane ke steps

1. github.com par login karo -> upar right `+` -> **New repository**.
2. Repository name: **KPsOptionsApk** -> **Private** -> **Create repository**. (Pehle ke KPsTradeHub repo ko mat chhedo - ye alag repo hai.)
3. Naye repo ke page par **uploading an existing file** link dabao.
4. `KPsOptionsApk_v110.zip` ko **bina kholay** drag-drop karo -> upload poora hone par neeche **Commit changes**.
5. **Add file -> Create new file**. Naam ke box me ye likho (slash type karte hi folder ban jaate hain):

   `.github/workflows/kpsoptionsapk.yml`

6. Saath di gayi `kpsoptionsapk.yml` Notepad me kholo -> **Ctrl+A, Ctrl+C** -> GitHub ke bade box me **Ctrl+V** -> **Commit changes**.
7. Upar **Actions** tab. Agar "Workflows aren't being run" jaisa kuch aaye: **Settings -> Actions -> General -> Allow all actions and reusable workflows -> Save**.
8. Actions -> left me **Build KPsOptionsApk** -> **Run workflow** (green) -> phir **Run workflow**.
9. 6-12 minute ruko. Hara tick aaye to repo ke home page par right side **Releases** -> **KPsOptionsApk build 1** -> `KPs_Options.apk` download.
   * Release nahi bana to: **Settings -> Actions -> General -> Workflow permissions -> Read and write permissions -> Save**, phir Run workflow dobara. (APK run ke page ke neeche **Artifacts** me bhi milti hai.)
10. Phone me `KPs_Options.apk` kholo -> **Install** (pehli baar "Install unknown apps" allow karna padega).

Purane (v100) se update: repo me purana `KPsOptionsApk_v100.zip` hatao (zip par click -> dustbin -> Commit), naya `KPsOptionsApk_v110.zip` upload karo. `kpsoptionsapk.yml` badalne ki zaroorat nahi. Phir Run workflow, aur APK purane ke upar install karo (settings bachi rehti hain).

Naya version banana ho to: repo me purana zip hatao (zip par click -> dustbin -> Commit), naya zip upload karo, Run workflow. `app/build.gradle` me `versionCode` har baar badhna chahiye.
Repo me **sirf ek zip** (`KPsOptionsApk*.zip`) aur **sirf ek yml** rakho.

## License key (naya)
Ye app bhi baaki KP apps jaisa license se chalta hai (wahi license module, wahi key format `AIAT1.…`, wahi seller ki keygen se key banti hai - purani keygen / public key waisi hi chalti hai).
1. App kholo -> **Kite login** tab -> sabse upar **🔑 License** card. Upar header me bhi "License needed / License OK" pill dikhta hai (dabane par wahi card khulta hai).
2. **Machine ID** (is phone ki, jaise `5B13-FBAC-0046`) -> **Copy Machine ID** -> seller ko bhejo. Key usi Machine ID ke liye banti hai.
3. Seller ki bheji key **License key** box me paste -> **Activate**. Card me plan aur aakhri valid din dikhta hai.
4. License na ho / expire ho / phone ki date peeche kar di ho to: **Start, Analyze, Paper trade** band (laal banner dikhta hai). **Stop, khuli position ka SL / target / exit, Settings, Trades** chalte rehte hain. Chalte hue license khatam ho jaye to naye entry band ho jaate hain, khuli positions manage hoti rehti hain.
5. Machine ID ek hi phone par hamesha wahi rehti hai (app update par bhi). Sirf **uninstall / Clear data** par badal jaati hai - tab nayi key leni padegi.
6. Har KP app ka license alag hota hai (Machine ID bhi alag), isliye Options ki key alag se activate karni hoti hai.

## Phone me pehli baar
1. App kholo (pehli baar 10-20 second lagte hain), notification allow karo, "Battery - Unrestricted / Allow" wala sawal aaye to **Continue** -> allow.
2. **Kite login tab**: API key + secret -> Save -> Login to Zerodha. Kite developer app me **Redirect URL = `http://127.0.0.1:5000/`** hona chahiye.
   Login Zerodha ka page app ke andar khulta hai aur apne aap wapas dashboard par aa jata hai. Roz subah ek baar login (token ~6 AM expire).
   Dhyan: KP's Algo / Multi / Pine / Auto bhi redirect port 5000 use karte hain - ek time par ek hi app me login karo.
3. **DRY RUN (paper) me kam se kam 3-5 din** chalao. LIVE ke liye DRY RUN badge dabao -> LIVE likho.
4. Trade ke dauran phone ON, app ki notification ("KP's Options is running") dikhe, internet ON. Battery optimisation "Unrestricted" rakho.

## Is app me kya hai
* PC wale KP's Options v9 ke saare mode: AUTO, MULTI, PINE, MCX, HERO-ZERO, Trade idea, Target box, Profit lock, Google AI (Gemini) second opinion. Poori detail: `KPs_Options/app/src/main/assets/algo_ai/README_HINGLISH.txt`.
* Phone ke liye: IST clock fix, foreground service + wake lock + Wi-Fi lock (screen off par chalta rahe), Zerodha login WebView me, app dobara kholne par page wapas jag jata hai.
* Network blip: Kite ke GET calls (quote / candles / positions) ek baar apne aap dobara try hote hain, aur "connect hi nahi hua" wale case me bhi ek retry. Order wali calls kabhi repeat nahi hoti (double order ka khatra nahi).
  Engine ka loop har second chalta hai aur network error par rukta nahi - net aate hi agle second se SL / target / exit wapas chalu.

## Zaroori baatein
* Option premium ki candles ke liye Kite Connect ka **Historical Data plan** chahiye (free personal plan me nahi aata).
* SEBI / Zerodha ke algo rules: API orders par static IP jaisi shart ho sakti hai (phone ka IP badalta rehta hai) - Kite developer console me check karo.
* SL / target SOFTWARE hain: phone chalu + internet chalu rehna chahiye. Bade trade me Kite me alag SL / alert bhi rakho.
* Munafe ki koi guarantee nahi. Pehle DRY RUN, phir 1 lot.
* App ka data (settings, Kite keys, trades) phone ke private folder me hai. Uninstall / Clear data par ye chale jaate hain.

## Agar Actions me error aaye
1. Repo me **sirf ek zip** aur `.github/workflows/` me **sirf ek yml** rakho.
2. Lal cross wale run ko kholo -> **lal step** kholo -> uske aakhri 20-30 line ka text (ya screenshot) bhej do.

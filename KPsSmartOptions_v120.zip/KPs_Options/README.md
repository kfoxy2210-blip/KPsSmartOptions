# KP's Options (Android)

PC wale **KP's Options v9 (Together)** ka Android version. Wahi program (Flask, port 5090) phone ke andar chalta hai, dashboard app ke WebView me khulta hai,
aur ek foreground service engine ko screen band hone par bhi chalu rakhti hai.

* App ID: `com.kp.options` | Dashboard: `http://127.0.0.1:5090` | App ka naam: KP's Options
* Engine code: `app/src/main/assets/algo_ai/` (PC wale files jaise ke taise: app.py, engine.py, opt_signal.py, kite_io.py, contracts.py, config.py, ai_gate.py, templates/)
* Android glue: `app/src/main/python/android_entry.py` (IST clock, login page WebView me, PC ka auto-browser band), `app/src/main/java/.../AlgoService.java` (foreground service, wake lock, Wi-Fi lock), `MainActivity.java` (WebView)
* License: `license_manager.pyc` + `license_public_key.pyc` + `ed25519_pure.pyc` (KP apps wale hi). Machine ID Kite login tab ke License card me dikhti hai.
* Settings / token / trades phone ke private folder me rehte hain (app update par bache rehte hain, "Clear data" / uninstall par jaate hain).

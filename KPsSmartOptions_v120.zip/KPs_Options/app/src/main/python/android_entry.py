"""
Android entry point for KP's Options (called from AlgoService through Chaquopy).

Runs the program exactly as `python app.py` does on a PC (Flask on http://127.0.0.1:5090), with only these
environment adjustments - the trading code itself is not touched:
  * working folder = the app's private folder (settings.json, kite_token.json, trades.json, open_positions.json live there)
  * "open the browser" (Zerodha login page) is redirected to the in-app WebView
  * the PC's auto-open-browser timer is switched off (the app's own WebView shows the dashboard)
  * the phone clock is pinned to IST (market hours)
"""
import os
import sys
import time
import traceback


def _pin_ist():
    for name in ("Asia/Kolkata", "IST-5:30", "Asia/Calcutta"):
        os.environ["TZ"] = name
        try:
            time.tzset()
        except Exception:                # noqa: BLE001
            continue
        if time.localtime().tm_gmtoff == 19800:
            break
    print("[android_entry] clock: %s (UTC%+d min) TZ=%s" % (
        time.strftime("%H:%M:%S"), time.localtime().tm_gmtoff // 60, os.environ.get("TZ")))


def _patch_browser():
    """webbrowser.open(url) -> show the page inside the app's WebView (Zerodha login)."""
    import webbrowser
    try:
        from java import jclass          # only exists inside Chaquopy
        bridge = jclass("com.algoai.trader.Bridge")

        def _open(url, new=0, autoraise=True):
            bridge.openUrl(str(url))
            return True
    except Exception:                    # noqa: BLE001 - running outside Android (tests / PC)
        def _open(url, new=0, autoraise=True):
            print("[android_entry] open this URL:", url)
            return True
    webbrowser.open = _open
    webbrowser.open_new = _open
    webbrowser.open_new_tab = _open


def _stable_device_id(app_dir):
    """Machine ID for the license check must stay the same on this phone.

    The license module derives the Machine ID from the network-adapter number (uuid.getnode()) when the OS has no machine id.
    Android hides the real adapter number, so Python would invent a NEW random one at every start. A random device number is
    generated ONCE here, saved in the app's private storage (device_id.dat) and reused (survives app updates; lost on uninstall /
    Clear data). The license check itself is not touched."""
    import secrets
    import uuid
    path = os.path.join(app_dir, "device_id.dat")
    value = None
    try:
        with open(path) as f:
            value = int(f.read().strip(), 16)
        if value <= 0 or value >> 48:
            value = None
    except Exception:                    # noqa: BLE001
        value = None
    if value is None:
        value = secrets.randbits(48) | (1 << 40)
        try:
            with open(path, "w") as f:
                f.write("%012x" % value)
        except Exception:                # noqa: BLE001
            pass
    uuid.getnode = lambda: value


def start(app_dir, port=5090):
    """Blocks for as long as the dashboard server runs. Run it in a background thread."""
    _pin_ist()
    os.chdir(app_dir)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    os.environ["KP_HOST"] = "127.0.0.1"
    os.environ["KP_OPT_PORT"] = str(int(port))
    sys.argv = ["app.py", "--no-browser"]
    _patch_browser()
    _stable_device_id(app_dir)
    try:
        import app as kp_options          # algo_ai/app.py (plain Python source)
        kp_options.main()
    except BaseException:                # noqa: BLE001 - SystemExit too, so the UI can show why
        traceback.print_exc()
        try:                             # the UI shows this file if the engine cannot start
            with open(os.path.join(app_dir, "android_error.txt"), "w") as f:
                f.write(traceback.format_exc())
        except Exception:                # noqa: BLE001
            pass
        raise

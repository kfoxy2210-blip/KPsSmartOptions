"""Optional Google Gemini 'second opinion' for KP's Options.

What it does:   after the normal rules have PICKED an option, the numbers of that option (premium candles, score,
                spread, lot cost, day change of the underlying...) are sent to Gemini. Gemini answers APPROVE / REJECT
                with a confidence % and a one-line reason. The engine only SKIPS the trade on REJECT / low confidence.
What it never does: place orders, pick contracts, change SL / target / quantity.
Only market numbers are sent - never your Kite keys, account, positions or P&L (except the end-of-day review, which
sends the list of today's trades when YOU press that button).

No extra library: plain urllib. Key lives in settings.json (your PC) or the GOOGLE_API_KEY / GEMINI_API_KEY env var.
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request
from collections import deque

import config

URL = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"
MAX_PER_MIN = 8                                   # stays under the free-tier request limit
_KEY_OK = re.compile(r"^[\x21-\x7E]{20,400}$")          # any printable, space-free text: Google has used several key formats
_calls = deque()
_lock = threading.Lock()


class AIError(Exception):
    pass


# ------------------------------------------------------------------ key storage
def _read():
    try:
        with open(config.PATH, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def get_key():
    k = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY") or _read().get("google_api_key", "")
    return str(k).strip()


def has_key():
    return bool(get_key())


def _write_key(value):
    with config._lock:
        d = _read()
        if value:
            d["google_api_key"] = value
        else:
            d.pop("google_api_key", None)
        tmp = config.PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.replace(tmp, config.PATH)
        try:
            os.chmod(config.PATH, 0o600)
        except OSError:
            pass


def clean_key(raw):
    """Forgiving paste: removes spaces / line breaks / quotes and a leading 'key=' or 'GOOGLE_API_KEY=' that people copy along."""
    k = re.sub(r"\s+", "", str(raw or ""))
    k = k.strip("\"'`")
    if "=" in k:
        k = k.rsplit("=", 1)[1].strip("\"'`")
    return k


def save_key(key):
    key = clean_key(key)
    if not _KEY_OK.match(key):
        raise AIError("Key bahut chhoti / adhoori lag rahi hai (%d characters). Google AI Studio -> Get API key se poori key copy karke paste karo." % len(key))
    _write_key(key)


def clear_key():
    _write_key("")


# ------------------------------------------------------------------ http
def _post(url, key, body, timeout):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json", "x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        hint = {400: "wrong model name or invalid key", 401: "key rejected", 403: "key not allowed for this model/API",
                404: "model not found (check the model name)", 429: "rate limit / quota reached"}.get(e.code, "server error")
        raise AIError("Google AI HTTP %d: %s%s" % (e.code, hint, _why(e, key)))
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise AIError("network problem: %s" % getattr(e, "reason", e))
    except ValueError:
        raise AIError("Google AI sent an unreadable answer")


def _why(e, key):
    """Google's own error sentence (safe to show; the key is blanked out if it is ever echoed)."""
    try:
        msg = str((json.loads(e.read().decode("utf-8", "replace")).get("error") or {}).get("message", ""))
    except Exception:                                   # noqa: BLE001
        return ""
    msg = msg.replace(key, "***").replace("\n", " ").strip()[:160]
    return " - Google says: " + msg if msg else ""


def _get(url, key, timeout):
    req = urllib.request.Request(url, method="GET", headers={"x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise AIError("Google AI HTTP %d%s" % (e.code, _why(e, key)))
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise AIError("network problem: %s" % getattr(e, "reason", e))
    except ValueError:
        raise AIError("Google AI sent an unreadable answer")


def _throttle():
    with _lock:
        now = time.time()
        while _calls and now - _calls[0] > 60:
            _calls.popleft()
        if len(_calls) >= MAX_PER_MIN:
            raise AIError("AI rate limit (%d calls/min) - skipped" % MAX_PER_MIN)
        _calls.append(now)


def _text(data):
    try:
        cand = (data.get("candidates") or [])[0]
    except (IndexError, AttributeError):
        why = (data.get("promptFeedback") or {}).get("blockReason") if isinstance(data, dict) else None
        raise AIError("AI gave no answer%s" % (" (blocked: %s)" % why if why else ""))
    parts = (cand.get("content") or {}).get("parts") or []
    txt = "".join(str(p.get("text", "")) for p in parts).strip()
    if not txt:
        raise AIError("AI answer was empty (finish: %s)" % cand.get("finishReason", "?"))
    return txt


def generate(a, system, user_text, json_mode=True, max_tokens=1024):
    key = get_key()
    if not key:
        raise AIError("Google AI key not saved (Settings -> Google AI)")
    model = str(a.get("model") or "gemini-2.5-flash").strip()
    gc = {"temperature": 0.1, "maxOutputTokens": max_tokens}
    if json_mode:
        gc["responseMimeType"] = "application/json"
    body = {"systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user_text}]}], "generationConfig": gc}
    _throttle()
    return _text(_post(URL % model, key, body, float(a.get("timeout_s", 6))))


# ------------------------------------------------------------------ second opinion
SYSTEM = (
    "You are a strict risk reviewer for an INTRADAY OPTION-BUYING bot (Indian markets: NSE/BSE index & stock options, "
    "MCX commodity options). A rules engine has ALREADY decided this option looks like a buy. Your only job is to catch "
    "setups that are likely to fail: late/over-extended moves, thin or erratic premium, wide spread vs. expected gain, "
    "choppy candles, a spike on one candle, too close to expiry, weak confirmation, exhaustion near day high, time of day "
    "(e.g. very late entry), opposite-side option also strong (conflicting signal). You cannot see news. Be conservative: "
    "REJECT when in real doubt. Use only the data given. Answer ONLY a JSON object: "
    '{"verdict":"APPROVE" or "REJECT","confidence":integer 0-100,"reason":"max 20 words, simple Hinglish"}. '
    "confidence = how sure you are of YOUR verdict."
)


def build_payload(r, ctx):
    """r = candidate row from the engine (with 'an' + 'raw_candles'); ctx = extra context. Numbers only."""
    an = r.get("an") or {}
    cs = []
    for c in (r.get("raw_candles") or [])[-12:]:
        t = c["t"]
        cs.append([t.strftime("%d %H:%M") if hasattr(t, "strftime") else str(t),
                   round(c["o"], 2), round(c["h"], 2), round(c["l"], 2), round(c["c"], 2), int(c["v"])])
    ltp = r.get("ltp") or 0
    atr = an.get("atr") or 0
    rnd = lambda x, n=2: None if x is None else round(float(x), n)  # noqa: E731
    return {
        "option": "%s %s strike %s expiry %s" % (r.get("und"), r.get("kind"), r.get("strike"), r.get("expiry")),
        "mode": ctx.get("mode"), "time_ist": ctx.get("time"), "days_to_expiry": ctx.get("dte"),
        "premium_ltp": rnd(ltp), "spread_pct": r.get("spread"), "cost_of_one_lot_rs": r.get("lot_cost"),
        "underlying_price": rnd(ctx.get("spot")), "underlying_day_change_pct": rnd(ctx.get("chg")),
        "rules_score": "%s of %s (needed %s)" % (r.get("score"), r.get("max") or 7, r.get("need")),
        "signals_passed": an.get("signals"), "opposite_option_score": ctx.get("opp_score"),
        "rsi": rnd(an.get("rsi"), 1), "efficiency_0_to_1": rnd(an.get("er"), 2), "atr": rnd(atr),
        "atr_pct_of_premium": rnd(atr / ltp * 100, 1) if ltp else None,
        "ema9": rnd(an.get("ema_fast")), "ema21": rnd(an.get("ema_slow")), "vwap": rnd(an.get("vwap")),
        "pine_break_pct_over_open": r.get("brk_pct"),
        "last_candles_[time,o,h,l,c,vol]": cs,
    }


def parse_verdict(txt):
    t = re.sub(r"^```(?:json)?|```$", "", txt.strip(), flags=re.I | re.M).strip()
    try:
        d = json.loads(t)
    except ValueError:
        m = re.search(r"\{.*\}", t, re.S)
        try:
            d = json.loads(m.group(0)) if m else None
        except ValueError:
            d = None
    if not isinstance(d, dict):
        raise AIError("AI answer was not valid JSON")
    v = str(d.get("verdict", "")).strip().upper()
    if v not in ("APPROVE", "REJECT"):
        raise AIError("AI verdict missing / unknown")
    try:
        conf = max(0, min(100, int(float(d.get("confidence", 0)))))
    except (TypeError, ValueError):
        conf = 0
    return {"verdict": v, "confidence": conf, "reason": str(d.get("reason", ""))[:200]}


def gate(payload, a):
    """-> {'verdict','confidence','reason'}; raises AIError on any problem (the engine applies your 'if AI fails' rule)."""
    return parse_verdict(generate(a, SYSTEM, json.dumps(payload, default=str)))


def list_models(timeout=10):
    """Names (without 'models/') of the Gemini models this key may call with generateContent, best first
    (newest 'flash' first - fast and cheap, which is what a per-trade opinion needs)."""
    key = get_key()
    if not key:
        raise AIError("Google AI key not saved (Settings -> Google AI)")
    data = _get("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", key, timeout)
    out = []
    for m in data.get("models", []):
        n = str(m.get("name", "")).replace("models/", "")
        if n.startswith("gemini") and "generateContent" in (m.get("supportedGenerationMethods") or []):
            out.append(n)

    def rank(n):
        v = re.search(r"gemini-(\d+(?:\.\d+)?)", n)
        bad = any(w in n for w in ("lite", "image", "tts", "live", "audio", "thinking", "embedding", "vision", "robotics", "computer"))
        return (0 if bad else 1, 1 if "flash" in n else 0, float(v.group(1)) if v else 0.0, 0 if "preview" in n or "exp" in n else 1, n)
    return sorted(out, key=rank, reverse=True)


def test(a):
    """-> (seconds, model used). If the saved model name is unknown / retired, the newest working Flash model is
    found automatically, saved to settings and used."""
    t0 = time.time()
    sysmsg, user = 'Reply ONLY with this JSON: {"verdict":"APPROVE","confidence":100,"reason":"ok"}', "ping"
    model = str(a.get("model") or "gemini-2.5-flash")
    try:
        parse_verdict(generate(a, sysmsg, user))
    except AIError as e:
        if not any(x in str(e) for x in ("HTTP 404", "HTTP 400", "not found")):
            raise
        names = [n for n in list_models() if n != model]
        if not names:
            raise
        a2 = dict(a, model=names[0])
        parse_verdict(generate(a2, sysmsg, user))
        model = names[0]
        config.save_patch({"ai": {"model": model}})
    return round(time.time() - t0, 1), model


# ------------------------------------------------------------------ end-of-day review (button)
REVIEW_SYSTEM = (
    "You are a calm trading coach reviewing today's INTRADAY OPTION-BUYING trades of a rule-based bot. Reply in simple "
    "Hinglish (Hindi in Roman letters), max 150 words, plain text, no markdown tables. Give: 1) one-line summary of the day, "
    "2) what pattern the LOSING trades share (time, side, script, exit reason), 3) at most 3 concrete, small settings ideas "
    "(e.g. later entry start, higher strictness, skip a script) to test in DRY RUN. Do not promise profits. If there are "
    "too few trades to say anything, say so."
)


def review(trades, a):
    rows = []
    for t in trades[:40]:
        ai = t.get("ai")
        rows.append({"option": t.get("symbol"), "mode": t.get("mode"), "in": str(t.get("entry_time", ""))[11:16],
                     "out": str(t.get("exit_time", ""))[11:16], "entry": t.get("entry"), "exit": t.get("exit"),
                     "qty": t.get("qty"), "pnl": t.get("pnl"), "exit_reason": t.get("reason"),
                     "ai_verdict": (ai or {}).get("verdict") if isinstance(ai, dict) else ai})
    if not rows:
        raise AIError("Aaj abhi koi trade nahi hua - review ke liye kuch nahi hai.")
    return generate(a, REVIEW_SYSTEM, json.dumps(rows, default=str), json_mode=False, max_tokens=700)

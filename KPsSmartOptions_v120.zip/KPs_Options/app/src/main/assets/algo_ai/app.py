"""KP's Options - local web app (http://127.0.0.1:5090). Analyses OPTION premiums directly and trades them."""
import os
import re
import sys
import threading
import time
import webbrowser

from flask import Flask, jsonify, render_template, request

import ai_gate
import config
import contracts
import kite_io
from engine import Engine

# ---- license (same module / key format as KP's Algo, Multi, Pine, Auto: seller makes a key for the Machine ID shown on the Kite login tab)
try:
    import license_manager as _lic
    _lic_load_err = None
except Exception as _exc:                                  # noqa: BLE001 - no license module = fail CLOSED (nothing can start)
    _lic = None
    _lic_load_err = str(_exc)

PORT = int(os.environ.get("KP_OPT_PORT", "5090"))
HOST = os.environ.get("KP_HOST", "127.0.0.1")
app = Flask(__name__)
eng = None
_HHMM = re.compile(r"^([01]?\d|2[0-3]):[0-5]\d$")
KINDS = {"CALL", "PUT", "BOTH"}
MODES = {"NORMAL", "AUTO", "MULTI", "PINE", "MCX", "HERO"}
ENTRY_MODES = {"Open-break + AUTO score", "Open-break only", "AUTO score only (instant)"}
_NAME_OK = re.compile(r"^[A-Z0-9&\-]{1,20}$")
_MODEL_OK = re.compile(r"^[A-Za-z0-9._\-]{1,60}$")
# (min, max) for numeric settings - stops a typo (e.g. 100 lots, SL 300%) from reaching the broker
RANGES = {"lots": (1, 200), "max_lots": (1, 200), "budget": (100, 10_000_000), "min_days": (0, 60), "min_premium": (0, 100000),
          "max_premium": (1, 100000), "max_spread_pct": (0.1, 50), "max_trades_day": (1, 100), "daily_max_loss": (0, 10_000_000),
          "max_loss_trade": (0, 10_000_000), "cooldown_min": (0, 240), "sl_atr_mult": (0.2, 10), "sl_min_pct": (1, 90),
          "sl_max_pct": (1, 95), "sl_fixed_pct": (1, 95), "rr": (0.2, 20), "be_r": (0.1, 10), "trail_start_r": (0.1, 20),
          "trail_mult": (0.1, 10), "ema_fast": (2, 100), "ema_slow": (3, 300), "rsi_len": (2, 50), "rsi_max": (50, 100),
          "min_er": (0, 1), "min_confidence": (0, 100), "timeout_s": (2, 30), "er_len": (3, 60), "breakout_n": (2, 60), "atr_len": (2, 60), "entry_buffer_pct": (0, 5),
          "exit_buffer_pct": (0, 10), "fill_wait_s": (1, 60), "slip_pct": (0, 5), "max_open": (1, 20), "min_edge": (0, 7),
          "break_pct": (0, 50), "min_ticks": (0, 100), "entry_bars": (1, 60), "orb_minutes": (1, 120), "offset": (-10, 10),
          # targets / accuracy / safety
          "target_pct": (1, 300), "profit_lock_pct": (0, 100), "rr_min": (0, 10), "reach_hold_bars": (2, 60), "reach_lookback": (15, 200),
          "spot_confirm_mins": (1, 30), "spot_confirm_pct": (0, 2), "max_chase_pct": (0, 1000), "chase_bars": (2, 60),
          "min_opt_volume": (0, 10_000_000_000), "min_opt_oi": (0, 10_000_000_000), "max_order_value": (0, 100_000_000),
          # HERO-ZERO
          "scan_steps": (0, 15), "min_volume": (0, 10_000_000_000), "sl_pct": (5, 95), "target_x": (2, 20), "min_score": (1, 6),
          "min_surge": (1, 20), "min_gain_pct": (0, 500), "max_run_pct": (10, 2000), "stale_exit_min": (0, 240),
          "max_trades": (1, 50), "max_loss_day": (0, 10_000_000)}
_uni = {"day": None, "live": False, "items": None, "tried": 0.0}
_umcx = {"day": None, "live": False, "items": None, "tried": 0.0}
_watch = {"at": 0.0, "data": {}}
_watch_lock = threading.Lock()


def _coerce(default, val):
    if isinstance(default, bool):
        return val if isinstance(val, bool) else str(val).lower() in ("1", "true", "yes", "on")
    if isinstance(default, int):
        return int(float(val))
    if isinstance(default, float):
        return float(val)
    return str(val).strip()


def clean_patch(patch):
    """Keep only known keys, cast to the right types, validate the risky ones."""
    out = {}
    d = config.DEFAULTS
    if "mode" in patch:
        m = str(patch["mode"]).upper()
        if m not in MODES:
            raise ValueError("mode must be one of %s" % sorted(MODES))
        out["mode"] = m
    for sec in ("common", "normal", "auto", "multi", "pine", "mcx", "hero", "ai"):
        if sec not in patch:
            continue
        o = {}
        for k, v in patch[sec].items():
            if k not in d[sec]:
                continue
            dv = d[sec][k]
            if k in ("max_qty_per_order", "lot_override"):
                if isinstance(v, str):                      # "CRUDEOIL=100, NATURALGAS=1250"
                    pairs = [p.split("=", 1) for p in re.split(r"[,;\n]+", v) if "=" in p]
                    v = {a.strip(): b.strip() for a, b in pairs if a.strip() and b.strip()}
                o[k] = {str(a).upper().strip(): int(float(b)) for a, b in (v or {}).items()}
                if any(n < 0 or n > 10_000_000 for n in o[k].values()):
                    raise ValueError("%s: quantities must be between 0 and 10,000,000 (0 = remove)" % k)
            elif isinstance(dv, list):
                items = v if isinstance(v, list) else re.split(r"[,\s]+", str(v).strip())
                items = [i for i in items if str(i).strip() != ""]
                o[k] = [int(float(i)) for i in items] if dv and isinstance(dv[0], int) else [str(i).upper().strip() for i in items]
                if not o[k]:
                    raise ValueError("%s cannot be empty" % k)
            else:
                o[k] = _coerce(dv, v)
            if k in RANGES and not isinstance(o[k], bool):
                lo, hi = RANGES[k]
                if not lo <= o[k] <= hi:
                    raise ValueError("%s must be between %s and %s" % (k, lo, hi))
            if k == "offsets" and any(abs(x) > 10 for x in o[k]):
                raise ValueError("strikes must be between -10 and 10")
            if k in ("underlying", "underlyings"):
                for n in ([o[k]] if k == "underlying" else o[k]):
                    if not _NAME_OK.match(str(n).upper()):
                        raise ValueError("'%s' is not a valid symbol" % n)
                    if sec == "mcx":
                        mu = mcx_universe()
                        if mu["live"] and n.upper() not in {i["name"] for i in mu["items"]}:
                            raise ValueError("%s has no options on MCX today" % n)
                    elif universe()["live"] and n.upper() not in _known_names():
                        raise ValueError("%s has no options in the F&O list" % n)
            if k in ("entry_start", "entry_end", "force_exit", "session_open", "market_close") and not _HHMM.match(str(o[k])):
                raise ValueError("%s must be HH:MM" % k)
            if k == "side" and str(o[k]).upper() not in KINDS:
                raise ValueError("side must be CALL / PUT / BOTH")
            if k == "side":
                o[k] = str(o[k]).upper()
            if k == "entry_mode" and o[k] not in ENTRY_MODES:
                raise ValueError("unknown Pine entry mode")
            if k == "underlying":
                o[k] = str(o[k]).upper()
            if k == "model" and not _MODEL_OK.match(o[k]):
                raise ValueError("model name looks wrong (example: gemini-2.5-flash)")
            if k == "lot_guard":
                o[k] = str(o[k]).upper()
                if o[k] not in ("WARN", "BLOCK_LIVE"):
                    raise ValueError("lot guard must be WARN or BLOCK_LIVE")
            if k == "target_mode":
                o[k] = str(o[k]).upper()
                if o[k] not in ("RR", "PCT", "AUTO"):
                    raise ValueError("target mode must be RR, PCT or AUTO")
            if k == "avoid_windows":
                o[k] = str(o[k]).replace(" ", "")
                if o[k] and not all(re.match(r"^([01]?\d|2[0-3]):[0-5]\d-([01]?\d|2[0-3]):[0-5]\d$", w) for w in re.split(r"[,;]", o[k])):
                    raise ValueError("avoid windows look like 11:45-13:15 (separate several with commas)")
            if k == "trend_gate":
                o[k] = str(o[k]).upper()
                if o[k] not in ("STRICT", "LOOSE", "OFF"):
                    raise ValueError("entry gate must be STRICT, LOOSE or OFF")
            if k == "on_error":
                o[k] = str(o[k]).upper()
                if o[k] not in ("ALLOW", "SKIP"):
                    raise ValueError("if AI fails must be ALLOW or SKIP")
        out[sec] = o
    hr = out.get("hero", {})
    if hr.get("interval") not in (None, "minute", "3minute", "5minute"):
        raise ValueError("Hero-Zero candle must be minute, 3minute or 5minute")
    if {"min_premium", "max_premium"} <= hr.keys() and hr["min_premium"] >= hr["max_premium"]:
        raise ValueError("Hero-Zero min premium must be below max premium")
    for sec in ("common", "mcx", "hero"):
        if out.get(sec, {}).get("product") not in (None, "MIS", "NRML"):
            raise ValueError("product must be MIS or NRML")
        if out.get(sec, {}).get("sizing") not in (None, "LOTS", "BUDGET"):
            raise ValueError("sizing must be LOTS or BUDGET")
    cm = out.get("common", {})
    if {"sl_min_pct", "sl_max_pct"} <= cm.keys() and cm["sl_min_pct"] > cm["sl_max_pct"]:
        raise ValueError("SL min % cannot be above SL max %")
    if cm.get("sl_mode") not in (None, "ATR", "FIXED"):
        raise ValueError("sl_mode must be ATR or FIXED")
    if cm.get("interval") not in (None, "minute", "3minute", "5minute", "10minute", "15minute"):
        raise ValueError("bad candle interval")
    return out


def _known_names():
    """Names we accept as underlying: static list, plus the live Kite list when we have it."""
    return {i["name"] for i in universe()["items"]}


def universe():
    """Indices + F&O stocks. Live from Kite (cached for the day) when logged in, else the built-in list."""
    day = kite_io.ist_now().date()
    if _uni["day"] == day and _uni["items"] and (_uni["live"] or not kite_io.connected()):
        return _uni
    live, items = False, None
    if kite_io.connected() and time.time() - _uni["tried"] > 60:      # do not hammer Kite if the list fails to load
        _uni["tried"] = time.time()
        try:
            try:
                bfo = kite_io.instruments("BFO")                # Sensex / Bankex expiries (needed for the expiry-today tag)
            except Exception:                               # noqa: BLE001
                bfo = None
            items = contracts.build_universe(kite_io.instruments("NFO"), bfo, day)
            live = len(items) > len(contracts.INDEX) + 20
        except Exception:                                   # noqa: BLE001 - fall back to the built-in list
            items = None
    _uni.update(day=day, live=live, items=items if live else contracts.static_universe())
    return _uni


def mcx_universe():
    """MCX commodities that have options. Live from Kite (cached for the day) when logged in, else the built-in list."""
    day = kite_io.ist_now().date()
    if _umcx["day"] == day and _umcx["items"] and (_umcx["live"] or not kite_io.connected()):
        return _umcx
    live, items = False, None
    if kite_io.connected() and time.time() - _umcx["tried"] > 60:
        _umcx["tried"] = time.time()
        try:
            items = contracts.build_mcx_universe(kite_io.instruments("MCX"), day)
            live = len(items) >= 2
        except Exception:                                   # noqa: BLE001
            items = None
    _umcx.update(day=day, live=live, items=items if live else contracts.static_mcx_universe())
    return _umcx


@app.before_request
def guard():
    """Local-only protection: a random web page must not be able to start/stop trades or change settings."""
    if HOST in ("127.0.0.1", "localhost") and request.host.split(":")[0] not in ("127.0.0.1", "localhost"):
        return err("Bad Host header", 403)
    if request.method == "POST" and request.headers.get("X-KP") != "1":
        return err("Blocked (missing X-KP header)", 403)


def ok(**kw):
    kw["ok"] = True
    return jsonify(kw)


_lic_cache = {"at": 0.0, "st": None}
_lic_lock = threading.Lock()


def lic_status(force=False):
    """License state (cached 20 s - the signature check is pure Python and a phone is slow)."""
    with _lic_lock:
        if not force and _lic_cache["st"] is not None and time.time() - _lic_cache["at"] < 20:
            return _lic_cache["st"]
        if _lic is None:
            st = {"machine_id": "?", "enforced": True, "active": False, "state": "ERROR",
                  "message": "License module missing (%s)." % _lic_load_err}
        else:
            try:
                st = dict(_lic.status())
            except Exception as e:                         # noqa: BLE001
                st = {"machine_id": "?", "enforced": True, "active": False, "state": "ERROR", "message": "License check failed: %s" % e}
        _lic_cache["at"], _lic_cache["st"] = time.time(), st
        return st


def lic_block():
    """None when allowed, else the sentence to show. Stop / exits / settings / trades are never blocked - only new entries."""
    st = lic_status()
    if st.get("enforced", True) and not st.get("active"):
        return "%s Open the 'Kite login' tab -> License card, paste your key, press Activate. (Machine ID: %s)" % (
            st.get("message") or "License required.", st.get("machine_id"))
    return None


def _lic_watch():
    """If the license lapses while running (expiry, clock set back) new entries stop; open positions keep being managed."""
    while True:
        time.sleep(30)
        try:
            if eng is not None and eng.running and lic_block():
                eng.stop()
                eng.log("License not active - new entries stopped (open positions are still managed).", "err")
        except Exception:                                  # noqa: BLE001
            pass


def err(msg, code=400):
    return jsonify({"ok": False, "error": str(msg)}), code


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/state")
def api_state():
    s = eng.state()
    s["ok"] = True
    st = lic_status()
    s["license"] = {k: st.get(k) for k in ("machine_id", "enforced", "active", "state", "message", "plan", "expires", "days_left")}
    return jsonify(s)


@app.get("/api/license")
def api_license():
    return ok(**lic_status(True))


@app.post("/api/license/activate")
def api_license_activate():
    key = str((request.get_json(force=True, silent=True) or {}).get("key", "")).strip()
    if not key:
        return err("Paste the license key first.")
    if _lic is None:
        return err("License module missing (%s)." % _lic_load_err, 500)
    try:
        _lic.activate(key)
    except Exception as e:                                 # noqa: BLE001 - LicenseError carries a clear sentence
        _lic_cache["st"] = None
        return err(e)
    st = lic_status(True)
    return ok(**st)


@app.get("/api/universe")
def api_universe():
    u, m = universe(), mcx_universe()
    return ok(items=u["items"], live=u["live"], liquid=contracts.LIQUID, sectors=["Index"] + list(contracts.SECTORS) + ["Other"],
              mcx=m["items"], mcx_live=m["live"], mcx_liquid=contracts.MCX_LIQUID)


@app.get("/api/watch")
def api_watch():
    """Spot price + day change % for the whole universe in ONE quote call (cached 4 s) - used to rank / pick fast."""
    if not kite_io.connected():
        return ok(data={}, age=None, connected=False)
    with _watch_lock:
        if time.time() - _watch["at"] > 4:
            items = universe()["items"]
            try:
                items = items + mcx_universe()["items"]
            except Exception:                                # noqa: BLE001 - MCX list problem must not break the equity picker
                pass
            keys = {i["spot"]: i["name"] for i in items if i.get("spot")}
            try:
                q = kite_io.quote(list(keys))
            except Exception as e:                           # noqa: BLE001
                return err(e)
            data = {}
            for k, name in keys.items():
                d = q.get(k) or {}
                ltp, prev = d.get("last_price"), (d.get("ohlc") or {}).get("close")
                if ltp:
                    data[name] = {"ltp": ltp, "chg": round((ltp / prev - 1) * 100, 2) if prev else None}
            _watch.update(at=time.time(), data=data)
        return ok(data=_watch["data"], age=round(time.time() - _watch["at"], 1), connected=True)


@app.post("/api/settings")
def api_settings():
    try:
        patch = clean_patch(request.get_json(force=True) or {})
    except (ValueError, TypeError) as e:
        return err(e)
    config.save_patch(patch)
    eng.log("Settings saved.")
    return ok()


@app.post("/api/live")
def api_live():
    d = request.get_json(force=True) or {}
    if d.get("live"):
        if str(d.get("confirm", "")).strip() != "LIVE":
            return err("Type LIVE to confirm real-money trading.")
        config.save_patch({"dry_run": False})
        eng.log("*** LIVE mode ON - real orders will be placed ***", "warn")
    else:
        config.save_patch({"dry_run": True})
        eng.log("Switched to DRY RUN (paper trading).")
    return ok()


@app.post("/api/start")
def api_start():
    msg = lic_block()
    if msg:
        return err(msg, 403)
    eng.start()
    return ok()


@app.post("/api/stop")
def api_stop():
    eng.stop()
    return ok()


@app.post("/api/exit")
def api_exit():
    pid = (request.get_json(force=True) or {}).get("id", "")
    return ok() if eng.exit_position(pid) else err("position not found")


@app.post("/api/exit_all")
def api_exit_all():
    eng.exit_all()
    return ok()


@app.post("/api/take")
def api_take():
    msg = lic_block()
    if msg:
        return err(msg, 403)
    sym = str((request.get_json(force=True) or {}).get("symbol", ""))[:40]
    try:
        r = eng.take_idea(sym)
    except Exception as e:                              # noqa: BLE001
        return err(e)
    return jsonify(r)


@app.post("/api/analyze")
def api_analyze():
    msg = lic_block()
    if msg:
        return err(msg, 403)
    try:
        r = eng.analyze_now()
    except Exception as e:                              # noqa: BLE001
        return err(e)
    return jsonify(r)


# ---------------------------------------------------------------- Google AI (optional second opinion)
@app.post("/api/ai/key")
def api_ai_key():
    try:
        ai_gate.save_key((request.get_json(force=True) or {}).get("key", ""))
    except ai_gate.AIError as e:
        return err(e)
    eng.log("Google AI key saved.")
    return ok(has_key=True)


@app.post("/api/ai/clear_key")
def api_ai_clear():
    ai_gate.clear_key()
    eng.log("Google AI key removed.")
    return ok(has_key=ai_gate.has_key())


@app.post("/api/ai/test")
def api_ai_test():
    try:
        secs, model = ai_gate.test(config.load()["ai"])
    except ai_gate.AIError as e:
        return err(e)
    return ok(seconds=secs, model=model)


@app.post("/api/ai/review")
def api_ai_review():
    try:
        txt = ai_gate.review(eng.state().get("trades", []), config.load()["ai"])
    except ai_gate.AIError as e:
        return err(e)
    return ok(text=txt)


# ---------------------------------------------------------------- Kite login
@app.post("/api/kite/keys")
def api_keys():
    d = request.get_json(force=True) or {}
    if not d.get("key") or not d.get("secret"):
        return err("API key aur secret dono daalo.")
    kite_io.save_keys(d["key"], d["secret"])
    return ok(status=kite_io.status())


@app.post("/api/kite/login")
def api_login():
    try:
        url = kite_io.login_url()
    except kite_io.KiteError as e:
        return err(e)
    auto = kite_io.start_redirect_listener(5000, "http://127.0.0.1:%d/" % PORT)
    return ok(url=url, auto=auto)


@app.post("/api/kite/complete")
def api_complete():
    try:
        kite_io.complete_login((request.get_json(force=True) or {}).get("text", ""))
    except kite_io.KiteError as e:
        return err(e)
    eng.log("Kite login OK.")
    return ok(status=kite_io.status())


@app.post("/api/kite/disconnect")
def api_disconnect():
    kite_io.disconnect()
    return ok()


def migrate_settings():
    """NORMAL mode was removed from the page: a saved NORMAL becomes AUTO (same symbol, both sides)."""
    cfg = config.load()
    if cfg.get("mode") == "NORMAL":
        config.save_patch({"mode": "AUTO", "auto": {"underlying": cfg["normal"]["underlying"],
                                                    "offsets": [int(cfg["normal"].get("offset", 0))]}})


def main():
    global eng
    migrate_settings()
    eng = Engine(kite_io)
    threading.Thread(target=_lic_watch, name="kp-license", daemon=True).start()
    if os.name == "nt":                                  # keep Windows awake while the program runs
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        except Exception:                                # noqa: BLE001
            pass
    if HOST == "127.0.0.1" and "--no-browser" not in sys.argv:
        threading.Timer(1.2, lambda: webbrowser.open("http://127.0.0.1:%d/" % PORT)).start()
    print("KP's Options running on http://%s:%d  (Ctrl+C to stop).  DRY RUN is the default." % (HOST, PORT))
    app.run(host=HOST, port=PORT, debug=False, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()

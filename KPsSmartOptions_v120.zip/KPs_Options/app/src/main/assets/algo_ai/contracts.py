"""Option contract resolution: underlying -> expiry -> strike -> exact CE / PE instrument."""
from datetime import date, datetime

# spot symbol, option exchange, default max qty per single order (freeze limits change - editable in Settings)
INDEX = {
    "NIFTY":      ("NSE:NIFTY 50",          "NFO", 1000),
    "BANKNIFTY":  ("NSE:NIFTY BANK",        "NFO", 500),
    "FINNIFTY":   ("NSE:NIFTY FIN SERVICE", "NFO", 1000),
    "MIDCPNIFTY": ("NSE:NIFTY MID SELECT",  "NFO", 2000),
    "SENSEX":     ("BSE:SENSEX",            "BFO", 500),
    "BANKEX":     ("BSE:BANKEX",            "BFO", 500),
}


# ---------------------------------------------------------------- MCX (commodity options)
# MCX options have no "spot": they are options ON A FUTURES contract, so the reference price is that future's LTP.
# name -> (label, group).  The live list from Kite (MCX instruments with CE/PE) decides what is really tradable.
MCX_INFO = {
    "CRUDEOIL": ("Crude Oil", "Energy"), "CRUDEOILM": ("Crude Oil Mini", "Energy"),
    "NATURALGAS": ("Natural Gas", "Energy"), "NATGASMINI": ("Natural Gas Mini", "Energy"),
    "GOLD": ("Gold", "Precious"), "GOLDM": ("Gold Mini", "Precious"), "GOLDPETAL": ("Gold Petal", "Precious"),
    "SILVER": ("Silver", "Precious"), "SILVERM": ("Silver Mini", "Precious"), "SILVERMIC": ("Silver Micro", "Precious"),
    "COPPER": ("Copper", "Base metals"), "ZINC": ("Zinc", "Base metals"), "ZINCMINI": ("Zinc Mini", "Base metals"),
    "LEAD": ("Lead", "Base metals"), "LEADMINI": ("Lead Mini", "Base metals"), "ALUMINIUM": ("Aluminium", "Base metals"),
    "ALUMINI": ("Aluminium Mini", "Base metals"), "NICKEL": ("Nickel", "Base metals"), "NICKELM": ("Nickel Mini", "Base metals"),
}
# Usual MCX contract size in the unit Kite uses for the order quantity. HINT ONLY: used to warn when Kite's list says
# something different (e.g. 1) - never used silently. Gold / silver are left out (their quantity unit differs per product).
MCX_REF_LOT = {"CRUDEOIL": 100, "CRUDEOILM": 10, "NATURALGAS": 1250, "NATGASMINI": 250, "COPPER": 2500,
               "ZINC": 5000, "ALUMINIUM": 5000, "LEAD": 5000}
MCX_LIQUID = ["CRUDEOIL", "NATURALGAS", "GOLD", "SILVER", "GOLDM", "SILVERM", "CRUDEOILM", "NATGASMINI"]
MCX_KNOWN = set(MCX_INFO)                       # grows with the live list (build_mcx_universe)


def is_mcx(name):
    return str(name).upper().strip() in MCX_KNOWN


def und_info(name):
    """-> (spot_key, option_exchange, default_max_qty_per_order).  MCX: spot_key is None (the future is resolved per
    expiry by the engine) and qty is not sliced by default (set 'max_qty_per_order' in settings if you need it)."""
    name = name.upper().strip()
    if name in INDEX:
        return INDEX[name]
    if name in MCX_KNOWN:
        return (None, "MCX", 0)
    return ("NSE:" + name, "NFO", 0)           # stock option: no slicing


def _to_date(x):
    if isinstance(x, datetime):
        return x.date()
    return x


class Chain:
    """Option chain of one underlying, built from the instrument list (cached by the caller)."""

    def __init__(self, name, rows):
        self.name = name.upper().strip()
        self.by = {}                            # expiry -> {(strike, kind): row}
        self.futs = []                          # futures of this name (MCX options are options on these)
        for r in rows:
            if str(r.get("name", "")).upper() != self.name:
                continue
            if r.get("instrument_type") == "FUT":
                self.futs.append(r)
                continue
            if r.get("instrument_type") not in ("CE", "PE"):
                continue
            exp = _to_date(r["expiry"])
            self.by.setdefault(exp, {})[(float(r["strike"]), r["instrument_type"])] = r
        self.expiries = sorted(self.by)
        self.futs.sort(key=lambda r: _to_date(r["expiry"]))

    def underlying_future(self, opt_expiry):
        """The future an MCX option sits on = the first future that expires on/after the option's expiry
        (crude: option 16-Nov -> future 19-Nov; gold: option 25-Nov -> future 5-Dec). None if not found."""
        for r in self.futs:
            if _to_date(r["expiry"]) >= opt_expiry:
                return r
        return None

    def pick_expiry(self, pref, today, min_days=0):
        """pref: NEAR | NEXT | MONTHLY | NEXT_MONTHLY | 'YYYY-MM-DD'."""
        ok = [e for e in self.expiries if (e - today).days >= max(0, int(min_days))]
        if not ok:
            return None
        pref = (pref or "NEAR").upper()
        if pref == "NEAR":
            return ok[0]
        if pref == "NEXT":
            return ok[1] if len(ok) > 1 else None
        if pref in ("MONTHLY", "NEXT_MONTHLY"):
            months = {}
            for e in ok:
                months[(e.year, e.month)] = e          # last expiry of each month
            keys = sorted(months)
            i = 0 if pref == "MONTHLY" else 1
            return months[keys[i]] if len(keys) > i else None
        try:
            d = datetime.strptime(pref, "%Y-%m-%d").date()
        except ValueError:
            return None
        return d if d in self.by else None

    def strikes(self, expiry):
        return sorted({k[0] for k in self.by.get(expiry, {})})

    def atm(self, expiry, spot):
        st = self.strikes(expiry)
        if not st:
            return None
        return min(st, key=lambda s: abs(s - spot))

    def contract(self, expiry, spot, kind, offset=0):
        """offset: 0 = ATM, +n = ITM n steps, -n = OTM n steps. kind 'CE' | 'PE'. -> instrument row or None."""
        st = self.strikes(expiry)
        if not st:
            return None
        i = min(range(len(st)), key=lambda j: abs(st[j] - spot))
        j = i - offset if kind == "CE" else i + offset
        if j < 0 or j >= len(st):
            return None
        return self.by[expiry].get((st[j], kind))


def clean(row):
    """Row -> small plain dict used everywhere in the app."""
    exp = _to_date(row["expiry"])
    return {"symbol": row["tradingsymbol"], "token": int(row["instrument_token"]), "exchange": row["exchange"],
            "kind": row["instrument_type"], "strike": float(row["strike"]), "expiry": exp.isoformat(),
            "lot": int(row["lot_size"]), "tick": float(row.get("tick_size") or 0.05)}


# ------------------------------------------------------------------ universe for the picker
INDEX_LABEL = {"NIFTY": "Nifty 50", "BANKNIFTY": "Bank Nifty", "FINNIFTY": "Fin Nifty", "MIDCPNIFTY": "Midcap Select",
               "SENSEX": "Sensex", "BANKEX": "Bankex"}

# sector -> F&O stocks (used for grouping; the live list from Kite decides what is actually tradable)
SECTORS = {
    "Banks & Finance": ["HDFCBANK", "ICICIBANK", "SBIN", "AXISBANK", "KOTAKBANK", "INDUSINDBK", "BANKBARODA", "PNB", "FEDERALBNK",
                        "IDFCFIRSTB", "AUBANK", "BANDHANBNK", "CANBK", "BAJFINANCE", "BAJAJFINSV", "SBILIFE", "HDFCLIFE",
                        "ICICIPRULI", "ICICIGI", "CHOLAFIN", "SHRIRAMFIN", "MUTHOOTFIN", "LICHSGFIN", "PFC", "RECLTD",
                        "JIOFIN", "SBICARD", "HDFCAMC"],
    "IT": ["TCS", "INFY", "HCLTECH", "WIPRO", "TECHM", "LTIM", "PERSISTENT", "COFORGE", "MPHASIS", "OFSS"],
    "Auto": ["TATAMOTORS", "MARUTI", "M&M", "BAJAJ-AUTO", "EICHERMOT", "HEROMOTOCO", "TVSMOTOR", "ASHOKLEY", "BOSCHLTD",
             "MOTHERSON", "BHARATFORG"],
    "Energy & Metals": ["RELIANCE", "ONGC", "NTPC", "POWERGRID", "COALINDIA", "BPCL", "IOC", "GAIL", "TATAPOWER", "ADANIGREEN",
                        "ADANIENT", "ADANIPORTS", "TATASTEEL", "JSWSTEEL", "HINDALCO", "VEDL", "JINDALSTEL", "SAIL", "NMDC",
                        "HINDZINC", "NATIONALUM"],
    "FMCG & Pharma": ["ITC", "HINDUNILVR", "NESTLEIND", "BRITANNIA", "TATACONSUM", "DABUR", "GODREJCP", "MARICO", "COLPAL",
                      "VBL", "UBL", "SUNPHARMA", "DRREDDY", "CIPLA", "DIVISLAB", "LUPIN", "AUROPHARMA", "TORNTPHARM",
                      "ZYDUSLIFE", "APOLLOHOSP", "MAXHEALTH"],
    "Infra & Consumer": ["LT", "ULTRACEMCO", "GRASIM", "AMBUJACEM", "SHREECEM", "DLF", "GODREJPROP", "TITAN", "ASIANPAINT",
                         "PIDILITIND", "HAVELLS", "POLYCAB", "SIEMENS", "ABB", "BHARTIARTL", "INDIGO", "TRENT", "DMART",
                         "ZOMATO", "NAUKRI", "IRCTC", "HAL", "BEL"],
}
OTHER_INDEX = {"NIFTYNXT50", "NIFTYIT", "NIFTYPSU", "NIFTYMID50"}          # index options we do not offer as "stocks"
_SECTOR_OF = {s: g for g, names in SECTORS.items() for s in names}
LIQUID = ["RELIANCE", "HDFCBANK", "ICICIBANK", "SBIN", "INFY", "TCS", "TATAMOTORS", "AXISBANK", "ITC", "LT", "BAJFINANCE",
          "KOTAKBANK", "BHARTIARTL", "M&M", "MARUTI", "TATASTEEL"]


def sector_of(name):
    return _SECTOR_OF.get(name.upper(), "Other")


def _item(name, kind, lot=None):
    return {"name": name, "kind": kind, "label": INDEX_LABEL.get(name, name),
            "sector": "Index" if kind == "INDEX" else sector_of(name), "lot": lot,
            "spot": und_info(name)[0], "liquid": name in LIQUID or kind == "INDEX"}


def static_universe():
    items = [_item(n, "INDEX") for n in INDEX]
    items += [_item(n, "STOCK") for g in SECTORS.values() for n in g]
    return items


def build_universe(nfo_rows, bfo_rows=None, today=None):
    """Indices + every stock that really has options today (from the NFO instrument list), with its lot size and, when
    `today` is given, its nearest expiry (exp_today = True on the expiry day: the Hero-Zero mode needs that)."""
    lots, near = {}, {}
    for rows, only_idx in ((nfo_rows, False), (bfo_rows or [], True)):
        for r in rows:
            n = str(r.get("name") or "").upper()
            if r.get("instrument_type") not in ("CE", "PE") or not n or (only_idx and n not in INDEX):
                continue
            lots.setdefault(n, int(r.get("lot_size") or 0))
            if today is not None and r.get("expiry") is not None:
                e = _to_date(r["expiry"])
                if e >= today and (n not in near or e < near[n]):
                    near[n] = e
    items = [_item(n, "INDEX", lots.get(n)) for n in INDEX]
    stocks = sorted(n for n in lots if n not in INDEX and n not in OTHER_INDEX)
    items += [_item(n, "STOCK", lots[n]) for n in stocks]
    for it in items:
        e = near.get(it["name"])
        it["exp"] = e.isoformat() if e else None
        it["exp_today"] = bool(e and today is not None and e == today)
    return items


def static_mcx_universe():
    items = []
    for n, (label, grp) in MCX_INFO.items():
        items.append({"name": n, "kind": "COMMODITY", "label": label, "sector": grp, "lot": None, "spot": None,
                      "liquid": n in MCX_LIQUID})
    return items


def build_mcx_universe(mcx_rows, today):
    """Every MCX name that really has options today, its lot size and the nearest future (used for the live % change)."""
    lots, near = {}, {}
    for r in mcx_rows:
        n, t = str(r.get("name", "")).upper(), r.get("instrument_type")
        if not n:
            continue
        if t in ("CE", "PE"):
            lots.setdefault(n, int(r.get("lot_size") or 0))
        elif t == "FUT":
            e = _to_date(r["expiry"])
            if e >= today and (n not in near or e < near[n][0]):
                near[n] = (e, r["tradingsymbol"])
    MCX_KNOWN.update(lots)
    order = list(MCX_INFO)
    names = sorted(lots, key=lambda n: (order.index(n) if n in order else 999, n))
    items = []
    for n in names:
        label, grp = MCX_INFO.get(n, (n.title(), "Other"))
        items.append({"name": n, "kind": "COMMODITY", "label": label, "sector": grp, "lot": lots[n],
                      "spot": ("MCX:" + near[n][1]) if n in near else None, "liquid": n in MCX_LIQUID})
    return items

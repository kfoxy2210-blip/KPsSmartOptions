KP's Options  -  seedha OPTION ke bhav (premium) ka analysis karke trade
=========================================================================
Ye naya project hai. Pehle ke projects index/stock chart dekhkar option chunte the. Yahan analysis OPTION ke apne premium
candles par hota hai (CALL aur PUT dono ke alag-alag), aur jo option khud chadh raha hai wahi kharida jata hai.

6 MODE (Mode tab me chuno, Save karo)
  NORMAL : aap underlying + side (CALL / PUT / BOTH) + strike chunte ho. Us option ka premium signal aate hi BUY.
  AUTO   : ek underlying; CALL aur PUT (aur jo strikes likho) scan karta hai; jis ka premium saaf zyada strong ho wahi BUY.
  MULTI  : AUTO kai underlyings par ek saath (NIFTY, BANKNIFTY, SENSEX, stocks...). Max N positions, ek underlying me ek.
  PINE   : 9:15 open-break strategy, option premium par: option ka premium apne 9:15 open se X% upar tute to BUY.
           Sirf shuru ke kuch candles me entry; force exit 11:30 (badal sakte ho). 3 entry modes (script jaise).

  MCX    : NAYA. MCX commodity options (Crude Oil, Natural Gas, Gold, Silver, Copper...). AUTO jaisa hi, lekin MCX scripts par:
           har script ke CALL + PUT ka premium scan hota hai, jo clearly strong ho wahi BUY. Detail neeche "MCX MODE" me.

  HERO-ZERO : NAYA. SIRF EXPIRY DAY par chalta hai. Sasta (low premium, default Rs3-30) OTM CALL/PUT dhundta hai jo breakout + volume surge
           ke saath chadh raha ho, aur 2x / 3x / 5x ka target rakhta hai. Detail neeche "HERO-ZERO MODE" me.

PREMIUM SIGNAL (7 checks): EMA9>EMA21, price>EMA9, VWAP ke upar, RSI 52-75, naya high (breakout), choppy nahi (efficiency),
  volume badhta hua.  Strictness 3/4/5/6 chuno. Hard rule: EMA trend + breakout + not-choppy zaroori, warna entry nahi.

HAR TRADE KA RISK (option premium par):  SL = option ATR x1.5 (10%-30% ke beech) | Target = 1.5 x SL | +0.7R par SL cost par |
  +1R ke baad trailing | Force exit 15:15 | Daily max loss | Max trades/day | Per-trade max loss (optional).
  Stop dabane par sirf NAYI entry band hoti hai; khuli positions ka SL/target/trail chalta rehta hai.

STOCK / INDEX FAST CHUNNA (naya)
  * Trade tab par upar Mode chuno -> "Pick stocks / indices" dabao. Tiles me har symbol ka aaj ka % change dikhta hai (Kite login ke baad live).
  * Search box: naam type karo (shortcut: / dabao). NORMAL/AUTO me Enter = pehla match chun liya.
  * Sort: Gainers / Losers / Movers. Sector buttons: Banks, IT, Auto, Energy & Metals, FMCG & Pharma, Infra.
  * Presets (MULTI/PINE): Nifty+BankNifty+Sensex, All indices, Liquid stocks (8), Top 4 gainers, Top 4 losers.
  * Jo chuno wo AUTO-SAVE ho jata hai ("Saved" dikhta hai) - alag Save button nahi. Strike (ATM/ITM/OTM) bhi wahin se.
  * Kite login ke baad list aaj ke asli F&O symbols + lot size se bhar jati hai. 16+ contracts scan hon to screen par chetavni aati hai
    (Kite ki history limit ~2 calls/sec - symbols kam = scan tez).

HERO-ZERO MODE (naya - sirf expiry day)
  * Trade tab -> "HERO-ZERO" mode chuno -> "Pick indices / stocks" (default NIFTY + SENSEX). Tiles par "EXPIRY" tag dikhta hai jis
    underlying ki expiry aaj hai. Presets: "Expiry today" (sirf aaj expiry wale) aur "Nifty + Sensex".
  * Expiry day nahi hai to ye mode koi trade nahi karta; screen par likha aata hai "not an expiry day - Hero-Zero waits".
    (Test ke liye Settings me "Run only on expiry day" untick kar sakte ho - sirf DRY RUN me.)
  * Kaise chunta hai: har underlying ke ATM se N strikes OTM tak (default 8) CALL aur PUT scan; sirf wahi jinka premium Rs3-30 ke beech ho
    (Settings me badal sakte ho), 1 lot budget (default Rs3000-4000) me aaye, spread <=12%, volume >= min.
  * Entry signal: option ka premium pichhle 4 candles ka high tode + price EMA9 ke upar + volume surge (ye 3 zaroori), aur 6 me se kam se kam
    4 checks pass. Jo option din ke low se pehle hi bahut chadh chuka ho (default +200%) use "too late" bolke chhod deta hai.
  * Risk: SL = premium ka 50% (fixed). Target = entry x 3 (Quick control me 2x / 3x / 5x). +0.8R par SL cost par, +1.2R ke baad trail.
    20 min tak follow-through na mile to "No follow-through" exit. 15:15 par force exit.
  * Alag limits: Hero ka apna budget, max lots (5), max positions (2), max trades/day (3) aur max loss/day (Rs3000). Ye EQ aur MCX se ALAG ginte hain.
  * Candle default 1 minute (fast entry); chaho to 3/5 minute. Entry window default 13:30-15:00 (Settings me badal sakte ho).
  * SACH: double/triple ki GUARANTEE koi nahi de sakta. Sasta expiry option aksar 0 ki taraf jata hai - zyada tar trades chhote loss me
    band honge, kabhi-kabhi ek bada jeet baaki sab bhar deti hai. Sirf wahi paisa lagao jo khone ka dar na ho. DRY RUN me kam se kam
    3-5 expiry din chalao, phir hi LIVE socho.

MCX MODE (naya)
  * Trade tab -> upar "MCX" mode chuno -> "Pick MCX scripts" dabao. Tiles me Crude, NatGas, Gold, Silver, Copper, Zinc... (Kite login ke baad
    sirf wahi jin par aaj options hain, lot size ke saath, aur live % change). Presets: Crude+NatGas, Gold+Silver, All liquid, Top 2 gainers/losers.
  * Side: CALL / PUT / BOTH (default BOTH = jo premium chadh raha ho). Strikes to scan: ATM/ITM/OTM. Choice AUTO-SAVE hoti hai.
  * MCX options FUTURES par hote hain, isliye ATM strike us future ke bhav se nikalta hai (option expiry ke baad wala pehla future:
    jaise Crude option 16-Nov -> future 19-Nov, Gold option 25-Nov -> future 5-Dec). Spot nahi hota.
  * Session 09:00-23:30 (Settings me "MCX session open / close"; US DST ke time MCX 23:55 tak chalta hai - tab close badal dena).
    Entries 09:20-22:30, force exit 23:15 (sab Settings -> MCX options me badal sakte ho).
  * MCX ke apne settings: lots / budget / max lots, premium range (5-5000), max spread, product (MIS/NRML). Equity wale settings alag rehte hain.
  * MCX ke trades aur daily max loss ALAG ginte hain. Subah NIFTY me loss hua to shaam ko MCX band nahi hoga (aur ulta bhi).
    Max trades/day aur daily max loss ki limit wahi common wali value hai, par count MCX ka alag hai.
  * LOT KA SIZE DHYAN SE: Analysis table me har option ke neeche "Rs/lot" dikhta hai. Rough idea: Crude/NatGas ek lot ~ Rs 10-20 hazaar,
    Gold/Silver ek lot lakh se upar ho sakta hai. Isliye default scripts sirf Crude + NatGas hain. Gold/Silver ke liye pehle dekho, phir jodo
    (ya Mini/Micro: GOLDM, SILVERM, SILVERMIC - agar aaj un par options listed hain).
  * Freeze quantity MCX ke liye default 0 (slicing band) rakhi hai. Badi qty karni ho to settings.json ke "max_qty_per_order" me
    {"CRUDEOIL": 5000} jaise apni exchange limit daalo.
  * DRY RUN me pehle 3-5 din chalao, equity jaisa hi. MCX par bhi koi guarantee nahi.

GOOGLE AI (GEMINI) SECOND OPINION (optional, default OFF)
  * Kya karta hai: rules jab koi option chunte hain, uske premium ke numbers (candles, score, spread, lot cost, underlying ka % change)
    Gemini ko jaate hain. Gemini APPROVE / REJECT + confidence % + ek line ki wajah deta hai. REJECT ya confidence kam ho to trade SKIP.
  * Kya NAHI karta: trade khud kholna, contract chunna, SL / target / qty badalna. Kite key, account, positions, P&L kabhi nahi bheje jaate.
    (Sirf "AI review" button dabane par aaj ke trades ki list bheji jaati hai.)
  * Setup: Google AI Studio se free API key lo -> Settings tab -> "Google AI (Gemini)" card -> key paste -> Save key -> Test AI ->
    "AI second opinion ON" tick -> Save settings. Key sirf aapke PC (settings.json) me rehti hai. Koi nayi library install nahi karni.
  * Model naam Settings me badal sakte ho (default gemini-2.5-flash). Google purane model band kar deta hai - agar Test AI "model not found"
    bole to AI Studio me chal raha naya Flash model ka naam daalo.
  * "If AI fails": ALLOW = AI band / error ho to bina AI ke pehle jaisa trade, SKIP = us case me trade nahi. Min confidence default 60%.
  * AI ka call alag thread me hota hai, isliye SL / target / exit kabhi nahi ruknaa. Entry me 1-3 second ka intezaar ho sakta hai.
    Ek option ke liye ek candle me ek hi baar poochha jaata hai (max 8 calls / minute).
  * Trade tab ke "Google AI second opinion" box me har faisla (time, option, verdict, confidence, wajah) dikhta hai, aur wahi verdict trade
    ke saath save hota hai. "AI review of today's trades" button din ka Hinglish summary + 3 chhote suggestions deta hai.
  * ZAROORI: AI se accuracy ki guarantee nahi. LLM ko news ya order-flow nahi dikhta, aur wo galat bhi ho sakta hai. Ise 5-10 din DRY RUN me
    ON rakhke dekho: "AI approved" trades sach me "AI skipped" se behtar the ya nahi. Faayda na dikhe to OFF kar do.
  * Free tier ki limits aur model availability Google badalta rehta hai - AI Studio me check karte raho.

TRADE IDEA + ZYADA TRADE (naya)
  * Trade tab me "Open positions" ke upar "Trade idea" box: har chune hue script ke liye jo CALL ya PUT sabse acha lag raha hai, uska
    strike, premium, Entry (approx), Stop-loss, Target, Risk/lot, Reward/lot aur score (kaun se signal kam hain). Start ya "Analyze now" par update hota hai.
    - READY    = saare rules pass, bot ye khareedega (entry window / limits ke andar).
    - BUILDING = ek signal kam. WEAK = abhi koi clear signal nahi: levels sirf "agar abhi kharido to" ke hain, bot ise nahi khareedega.
  * DRY RUN me har idea par "Paper trade now" button: ek paper trade turant khulta hai, taaki SL / target / trailing / exit ka flow aap dekh sako.
    LIVE mode me ye button nahi dikhta aur server bhi mana kar deta hai.
  * "Make it trade more (Active preset)": strictness Relaxed (3), entry gate LOOSE (EMA upar + RSI momentum, taza breakout zaroori nahi),
    efficiency 0.20, breakout 4 candle. "Back to Normal preset" se purane default (Normal 4, STRICT, 0.35, 6).
    Settings -> Signal tuning me "Entry gate" ke 3 option: STRICT (default) / LOOSE / OFF (sirf score).
  * Dhyan: zyada trade = zyada galat signal + zyada brokerage/slippage. Flat / choppy bazaar me Active preset bhi trade nahi dega
    (score 1/7-2/7 par kharidna jua hai). Pehle DRY RUN me Active preset 3-5 din chalao aur P&L dekho.

AUTO ME MAX POSITIONS + FAST ENTRY (naya)
  * Settings -> AUTO options -> "Max positions together". 1 = pehle jaisa. 2 ya zyada = ek position khuli ho tab bhi bot NAYA contract le sakta hai
    (alag strike ya alag side) us hi symbol par. Wahi contract dobara nahi kharidta. Cooldown aur "already open" rule ab symbol ke bajay
    contract par lagta hai. Doosra contract tabhi qualify karega jab wo scan ho raha ho: "Strikes to scan" me ATM ke saath ITM 1 / OTM 1 bhi chuno.
    MULTI aur MCX me ek script par ek hi position rehti hai.
  * Entry kyun late hoti thi (3 kaaran): (1) 3-minute candle, (2) slow EMA 9/21 + 6-candle breakout, (3) har trade ke baad 10 min cooldown.
  * "Fast entry preset" (Trade idea box me button): 1-minute candle, EMA 5/13, RSI 9, breakout 4 candle, efficiency 0.25, ATR 10, LOOSE gate,
    Relaxed (3), cooldown 3 min. Signal 2-4 candle jaldi aata hai. Simulator ke ek test din me Normal ne 09:51 par aur Fast ne 09:32 par entry li.
    "Back to Normal preset" sab kuch default par laa deta hai (3-minute, 9/21, STRICT, cooldown 10).
  * Fast ki kimat: 1-minute candle me noise zyada hota hai -> jhooti breakout, SL zyada baar, zyada brokerage/slippage; Kite ke historical-data
    calls bhi har minute badhte hain. Google AI ON ho to entry me 1-3 second aur lagte hain. Pehle DRY RUN me 3-5 din Normal vs Fast ka P&L
    compare karo (Today's trades me sab dikhta hai). Ek hi din ka result kuch sabit nahi karta.

TARGET BOX, R:R, MCX LOT, AI KEY, NAYE PARAMETERS (v8)
  1) Trade tab -> "Target & square-off" box:
     * Square off at % of investment: 12% / 15% / 20% (ya custom). Premium +12/15/20% hote hi trade apne aap square off.
       Jaise Rs10,000 lagaya, 15% -> Rs11,500 par exit. Stop-loss pehle jaisa (option ATR se, 10-30%). Agar % stop-loss se chhota hai
       (jaise SL 15%, target 12%) to box me chetavani aati hai (jeetne par kam, harne par zyada).
     * Risk : Reward: 1:1.5 / 1:2 / 1:2.5 (target = stop-loss ka itna guna), "Auto" (teeno me se sabse bada jo possible dikhe), "No target" (sirf trailing/SL).
     * "Trade only if the target looks reachable": >=1:1.5 / 1:2 / 1:2.5. Bot option ke apne pichhle candles dekhta hai: pichhle 40 candle me
       8 candle ke andar usne kitna upar move kiya (70th percentile). Itna move target ke liye kaafi ho tabhi entry. Ye ANDAZA hai, guarantee nahi.
       Data kam ho to ye filter block nahi karta. Trade idea card me har option ke 1:1.5 / 1:2 / 1:2.5 ke saamne hara tick (possible) ya laal (mushkil) dikhta hai.
  2) Google AI key accept nahi ho rahi thi - wajah: Google ki nayi keys me "." jaisa character hota hai aur purana check use reject kar deta tha.
     Ab koi bhi key chalti hai; paste me space / quotes / "GOOGLE_API_KEY=" sab apne aap hat jata hai. "Save settings" dabane par bhi box me paste ki hui key save hoti hai,
     aur Save key ke turant baad AI ka test chalta hai. Agar model naam purana ho gaya hai (404) to Test AI naya Flash model khud dhoondh ke Settings me save kar deta hai.
     Fail hone par Google ka asli error sentence dikhta hai (jaise "API key not valid" / "quota").
  3) MCX lot size: lot size seedha Kite ki list se aata hai, qty = lots x lot size (position me "Qty 200 (2 lot x 100)" dikhta hai).
     Agar Kite ki list kisi script ke liye usual MCX size se alag batati hai (jaise CRUDEOIL 1, jabki aam taur par 100) to:
       - tile par lot ke saath warning aur Trade idea me peeli chetavani,
       - bot phir bhi Kite ka lot size AUTO use karta hai (NIFTY / stock jaisa). Sirf Settings -> MCX -> "If Kite's lot size looks unusual" ko BLOCK_LIVE karoge to LIVE entry refuse hogi (default WARN),
       - Settings -> MCX options -> "Lot size override" me CRUDEOIL=100, NATURALGAS=1250 jaisa daalo (wahi number jo aapki Kite order window me 1 lot ka quantity step hai).
     Saath me "Max Rs per entry order" safety hai (MCX default 3,00,000): usse mehnga order nahi jayega, lots apne aap kam ho jaate hain.
     Gold / Silver ke liye warning nahi aati (unki quantity ki unit alag-alag hoti hai) - pehle Kite order window me ek lot ka qty dekh ke override daalo.
  4) Naye accuracy / speed parameters (Settings -> Accuracy filters, Speed & safety):
     spot_confirm (underlying pichhle 3 min me option ki disha me >=0.01% chale), max_chase_pct (spike ke baad 60% upar to nahi), min_opt_volume / min_opt_oi,
     avoid_windows (jaise 11:45-13:15), prefetch (paas ke strikes ke candles pehle se), max_order_value.
     Ye sab filters hain: trade kam karenge, par jhooti entry bhi kam. Accuracy BADHNE ki guarantee nahi - 3-5 din DRY RUN me ON/OFF compare karo.
  5) "Parameters" tab: program kya kya padhta hai aur kaun kaun se rules lagata hai, sab ek jagah.
  6) Naya premium look: gradient background, glass cards, mode ke rang, glow wale READY badge, animated header.

NORMAL HATA, MCX SAATH ME, PROFIT LOCK (v9)
  1) NORMAL mode page se hata diya. Purani saved setting me NORMAL tha to start par apne aap AUTO ban jata hai (wahi symbol aur strike).
  2) "Also run MCX scripts together": AUTO ya MULTI me symbol chips ke neeche tick karo, phir "Pick MCX scripts" se MCX script chuno.
     Ek hi run me equity (NIFTY / stock) aur MCX (Crude, NatGas...) dono scan hote hain. Har ek apne market ke time par chalta hai
     (equity 09:15-15:30, MCX 09:00-23:30) aur MCX ke liye uska apna box lagta hai: premium range, lots, entry / exit time,
     max positions, trades aur daily loss alag ginte hain. MCX ke strikes / side / lot override ek baar MCX mode aur Settings -> MCX me set karo.
     MCX positions "MCX" mode ke naam se dikhti hain. Ye option band ho to pehle jaisa: ek mode, ek time.
  3) PROFIT LOCK (Trade tab, Off / 10% ... 100%): aaj ke BOOKED (band hue) profit ka utna % hi naya trade loss le sakta hai.
     Jaise Rs10,000 profit book ho gaya aur 80% chuna -> naya trade -Rs8,000 par apne aap square off, din ka profit Rs2,000 bacha rahega.
     * Profit nahi hai (ya din loss me hai) to normal stop-loss chalta hai. Cap sirf NAYE trade par lagta hai, entry ke time ke profit se.
     * Cap stop-loss ki tarah lagta hai: agar normal SL cap se chhota hai to SL hi pehle lagega. Tez bazaar me price gap kare to loss cap se thoda zyada ho sakta hai.
     * Booked profit me sab modes ke trade jodte hain (equity + MCX). Cap bahut chhota ho (2 tick se kam) to wo trade skip hota hai aur note me wajah likhi aati hai.

START KAISE KARE
  1) run.bat double-click (Python 3.10+ chahiye).  Browser me http://127.0.0.1:5090 khulta hai.
  2) Kite login tab: API key + secret -> Save -> Login to Zerodha.  Kite developer app me Redirect URL: http://127.0.0.1:5000/
     (roz subah ek baar login; token ~6 AM expire hota hai).
  3) Mode + Entry & Risk settings dekho. PEHLE DRY RUN (paper) me kam se kam 3-5 din chalao. "Analyze now" se dekho ki
     kaun sa option kitna score le raha hai.
  4) Start dabao.  LIVE karne ke liye upar DRY RUN badge par click -> LIVE type karo.

LIVE ke baare me zaroori baatein (padhna)
  * Ye code maine simulator par test kiya hai (python selftest.py: 227 checks pass (MCX, AI, Trade idea, Fast, Hero, Target box ke sahit)) - asli Zerodha par nahi. Isliye DRY RUN se shuru,
    phir 1 lot se LIVE.
  * Munafa ki koi guarantee nahi. Random market me ye bhi haarta hai; signal ko aap apne data par parakhna.
  * Orders LIMIT hote hain (LTP se thoda upar BUY / neeche SELL) taaki Zerodha ka market-order protection na atke. Fill na ho to
    cancel ho jata hai aur entry skip hoti hai. Exit na ho paye to 5 baar retry, phir screen par laal warning: Kite me khud exit karo.
  * SL/Target SOFTWARE hain: PC + internet ON rehna chahiye. Bade trade me Kite me alag SL/alert bhi rakho.
  * Option premium ki candles ke liye Kite Connect ka HISTORICAL DATA plan chahiye (free personal plan me nahi aata).
  * Zerodha/SEBI ke algo rules ke hisaab se API orders ke liye static IP jaisi shart ho sakti hai - Kite developer console me check karo.
  * Freeze quantity (ek order me max qty) badalti rehti hai: Entry & Risk me nahi, settings.json ke "max_qty_per_order" me
    {"NIFTY": 1000} aise badal sakte ho. Default NIFTY 1000, BANKNIFTY 500, SENSEX 500 (badi qty khud slices me bat jati hai).
  * Restart par khuli positions open_positions.json se wapas uth jati hain. LIVE exit se pehle Kite ki position check hoti hai,
    agar aapne Kite se khud band kar di ho to app dobara SELL nahi bhejta (short nahi banega).

FILES: ai_gate.py (Google AI) | app.py (server) | engine.py (modes, entry, risk, orders) | opt_signal.py (premium analysis) | contracts.py (expiry/strike, MCX futures)
       kite_io.py (Zerodha) | config.py | templates/index.html | selftest.py (simulator test) | trades.json / engine.log (record)
Test chalane ke liye:  python selftest.py

SURAKSHA: app sirf aapke PC (127.0.0.1) par chalta hai. Koi dusri website ab Start/Stop/Settings nahi chala sakti (X-KP header + Host check).
  Agar KP_HOST=0.0.0.0 karke phone se kholte ho to wahi WiFi ke log bhi khol sakte hain - password nahi hai, isliye sirf apne ghar ke WiFi par.
  Settings me galat value (jaise 900 lots, SL 300%) ab save hi nahi hoti.


SMART AUTO (v1.2.0) - signal steady aur accurate
------------------------------------------------
* Signal ab 6 second tak tikna chahiye tabhi entry hoti hai (ek tick ki spike pe galat entry nahi).
* Ek side (CALL/PUT) kharidne ke baad 6 minute tak ulti side tabhi jab uska edge bada ho (CALL-PUT ping-pong band).
* Kuchh set nahi karna - defaults hi SMART hain. Badalna ho to Settings: confirm_s (seconds) aur flip_lock_min (minutes); 0 = band.

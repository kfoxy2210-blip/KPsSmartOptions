"""Settings: defaults + settings.json (deep-merged). Kite keys live in the same file but are never sent to the page."""
import copy
import json
import os
import threading

BASE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(BASE, "settings.json")
_lock = threading.Lock()

DEFAULTS = {
    "mode": "AUTO",                  # NORMAL | AUTO | MULTI | PINE | MCX | HERO
    "dry_run": True,                 # True = paper trading (no real orders)
    "common": {
        "lots": 1, "sizing": "LOTS", "budget": 20000, "max_lots": 10,
        "product": "MIS", "interval": "3minute", "expiry": "NEAR", "min_days": 0, "avoid_expiry_day": False,
        "min_premium": 15, "max_premium": 900, "max_spread_pct": 3.0,
        "entry_start": "09:25", "entry_end": "14:45", "force_exit": "15:15",
        "max_trades_day": 6, "daily_max_loss": 5000, "max_loss_trade": 0, "cooldown_min": 10,
        "sl_mode": "ATR", "sl_atr_mult": 1.5, "sl_min_pct": 10, "sl_max_pct": 30, "sl_fixed_pct": 20,
        "target_on": True, "rr": 1.5,
        # square-off target: RR = 1:rr of the stop-loss | PCT = +target_pct % of the money invested | AUTO = biggest of 1:1.5/2/2.5 that looks reachable
        "target_mode": "RR", "target_pct": 15.0,
        # trade only if a target of at least 1:rr_min looks reachable from the option's own recent moves (0 = off)
        "rr_min": 0.0, "reach_hold_bars": 8, "reach_lookback": 40,
        # extra accuracy filters
        "spot_confirm": True, "spot_confirm_mins": 3, "spot_confirm_pct": 0.01,   # underlying must be moving the option's way
        "max_chase_pct": 60.0, "chase_bars": 10,                                   # do not buy after a spike (% above the recent low; 0 = off)
        "min_opt_volume": 0, "min_opt_oi": 0,                                      # liquidity of the option itself (0 = off)
        "avoid_windows": "",                                                       # e.g. "11:45-13:15" = no new entries in that window
        "prefetch": True,                                                          # speed: keep candles of neighbouring strikes warm
        "max_order_value": 0,                                                      # safety: max Rs per entry order (0 = off)
        "profit_lock_pct": 0,                                                      # new trade may lose at most this % of today's booked profit (0 = off)
        "be_on": True, "be_r": 0.7,
        "trail_on": True, "trail_start_r": 1.0, "trail_mult": 1.0,
        "strictness": "Normal (4)", "trend_gate": "STRICT", "ema_fast": 9, "ema_slow": 21, "rsi_len": 14, "rsi_max": 75,
        "min_er": 0.35, "er_len": 10, "breakout_n": 6, "atr_len": 14,
        "entry_buffer_pct": 0.5, "exit_buffer_pct": 1.0, "fill_wait_s": 8, "slip_pct": 0.3,
        "max_qty_per_order": {},
        # SMART AUTO (stable signal): a pick must hold this many seconds; after a trade the other side needs a bigger edge for N minutes
        "confirm_s": 6, "flip_lock_min": 6,
    },
    "normal": {"underlying": "NIFTY", "side": "BOTH", "offset": 0},
    "auto":   {"underlying": "NIFTY", "offsets": [0], "min_edge": 1, "max_open": 1},
    "multi":  {"underlyings": ["NIFTY", "BANKNIFTY", "SENSEX"], "offsets": [0], "min_edge": 1, "max_open": 2},
    "pine":   {"underlyings": ["NIFTY"], "offset": 0, "entry_mode": "Open-break + AUTO score",
               "break_pct": 3.0, "min_ticks": 1, "confirm_on_close": False, "entry_bars": 5,
               "orb_minutes": 15, "force_exit": "11:30", "require_opposite_weak": True, "max_open": 1},
    # MCX commodity options: AUTO scan over many MCX scripts (CALL + PUT premium of each), best one is bought.
    # The keys in MCX_OVERRIDE replace the same keys of "common" while the MCX mode is active (MCX has its own
    # session, premium range and lot values); everything else (SL, target, trail, signal) is shared with "common".
    "mcx":    {"underlyings": ["CRUDEOIL", "NATURALGAS"], "offsets": [0], "side": "BOTH", "min_edge": 1, "max_open": 2,
               "sizing": "LOTS", "lots": 1, "budget": 20000, "max_lots": 3,
               "min_premium": 5, "max_premium": 5000, "max_spread_pct": 4.0, "product": "MIS",
               "session_open": "09:00", "market_close": "23:30",
               "entry_start": "09:20", "entry_end": "22:30", "force_exit": "23:15",
               "lot_override": {}, "lot_guard": "WARN", "max_order_value": 300000, "together": False},
}
# HERO-ZERO: expiry-day lottery buys. Cheap (low premium) OTM options that break out with volume, aiming at 2x-5x with a
# fixed stop. Counts its own trades / loss (like MCX) and uses its own size, timing and candle size.
DEFAULTS["hero"] = {
    "underlyings": ["NIFTY", "SENSEX"], "side": "BOTH", "only_expiry_day": True, "interval": "minute",
    "scan_steps": 8, "min_premium": 3.0, "max_premium": 30.0, "max_spread_pct": 12.0, "min_volume": 50000,
    "budget": 3000, "max_lots": 5, "max_open": 2, "product": "MIS",
    "entry_start": "13:30", "entry_end": "15:00", "force_exit": "15:15",
    "breakout_n": 4, "min_surge": 1.5, "min_gain_pct": 15.0, "max_run_pct": 200.0, "min_score": 4, "min_edge": 1,
    "sl_pct": 50.0, "target_x": 3.0, "be_r": 0.8, "trail_start_r": 1.2, "trail_mult": 0.8, "stale_exit_min": 20.0,
    "max_trades": 3, "max_loss_day": 3000, "cooldown_min": 3}
# hero key -> key of "common" that it replaces while a HERO position / mode is being handled
HERO_OVERRIDE = {"budget": "budget", "max_lots": "max_lots", "min_premium": "min_premium", "max_premium": "max_premium",
                 "max_spread_pct": "max_spread_pct", "product": "product", "entry_start": "entry_start", "entry_end": "entry_end",
                 "force_exit": "force_exit", "interval": "interval", "max_trades": "max_trades_day",
                 "max_loss_day": "daily_max_loss", "cooldown_min": "cooldown_min"}
DEFAULTS["ai"] = {                       # optional Google Gemini second opinion (OFF by default; key is saved separately)
    "enabled": False, "model": "gemini-2.5-flash", "min_confidence": 60, "on_error": "ALLOW", "timeout_s": 6}
MCX_OVERRIDE = ("sizing", "lots", "budget", "max_lots", "min_premium", "max_premium", "max_spread_pct", "product",
                "entry_start", "entry_end", "force_exit", "max_order_value")
SECRET = ("kite_api_key", "kite_api_secret", "google_api_key")


def _merge(base, patch):
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict) and k != "max_qty_per_order":
            _merge(base[k], v)
        else:
            base[k] = v
    return base


def load():
    with _lock:
        d = copy.deepcopy(DEFAULTS)
        try:
            with open(PATH, encoding="utf-8") as f:
                saved = json.load(f)
        except (OSError, ValueError):
            saved = {}
        return _merge(d, saved)


def effective(cfg, mode=None):
    """cfg['common'] as used by `mode` (default: the current mode). MCX replaces a few keys with its own values."""
    cc = dict(cfg["common"])
    m = mode or cfg["mode"]
    if m == "MCX":
        cc.update({k: cfg["mcx"][k] for k in MCX_OVERRIDE if k in cfg["mcx"]})
    elif m == "HERO":
        cc.update({c: cfg["hero"][h] for h, c in HERO_OVERRIDE.items() if h in cfg["hero"]})
        cc["sizing"] = "BUDGET"                          # hero trades are sized by a small rupee budget, never by lots
    return cc


def public():
    d = load()
    for k in SECRET:
        d.pop(k, None)
    return d


def save_patch(patch):
    """Merge `patch` into settings.json (keeps kite keys)."""
    patch = {k: v for k, v in patch.items() if k not in SECRET}
    with _lock:
        try:
            with open(PATH, encoding="utf-8") as f:
                saved = json.load(f)
        except (OSError, ValueError):
            saved = {}
        _merge(saved, patch)
        tmp = PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(saved, f, indent=2)
        os.replace(tmp, PATH)

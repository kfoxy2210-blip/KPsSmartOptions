"""KP's Options engine - analyses the OPTION PREMIUM itself and trades it. Modes: NORMAL | AUTO | MULTI | PINE | MCX | HERO (expiry-day hero-zero).

Runs in its own thread for as long as the program is open. Open positions are ALWAYS managed (SL / target / trail /
force-exit) even after you press Stop - Stop only blocks NEW entries.
"""
import collections
import copy
import json
import math
import os
import threading
import time
import traceback
from datetime import datetime, timedelta

import ai_gate
import config
import contracts
import opt_signal as sig

BASE = os.path.dirname(os.path.abspath(__file__))
INTERVAL_MIN = {"minute": 1, "3minute": 3, "5minute": 5, "10minute": 10, "15minute": 15}


def hm(s):
    h, m = str(s).split(":")[:2]
    return int(h) * 60 + int(m)


def mins(dt):
    return dt.hour * 60 + dt.minute


def grp(mode):
    """MCX and HERO trades / P&L / open positions are counted separately from the normal equity modes."""
    return mode if mode in ("MCX", "HERO") else "EQ"


def round_tick(p, tick, how="near"):
    tick = tick or 0.05
    n = p / tick
    n = math.floor(n + 1e-9) if how == "down" else math.ceil(n - 1e-9) if how == "up" else round(n)
    return round(max(n, 1) * tick, 2)


class Engine:
    def __init__(self, kio, clock=None, base=BASE, autostart=True):
        self.kio = kio
        self.clock = clock or kio.ist_now
        self.base = base
        self.pos_file = os.path.join(base, "open_positions.json")
        self.trades_file = os.path.join(base, "trades.json")
        self.log_file = os.path.join(base, "engine.log")
        self.lock = threading.RLock()
        self.running = False
        self.positions = {}
        self.trades = []
        self.logs = collections.deque(maxlen=400)
        self.spot = {}
        self.q = {}
        self.hc = {}
        self.chains = {}
        self.fut = {}                 # MCX: und -> (date, future key)
        self._fut_err = {}
        self.spot_hist = {}           # und -> deque[(time, price)] of spot ticks (underlying confirmation, no extra API calls)
        self.ideas = []               # per underlying: leaning CALL/PUT with entry / SL / target (shown even before a trade)
        self._rows_full = []
        self.ai_cache = {}            # (symbol, day, candle bucket) -> AI answer (one question per option per candle)
        self.ai_log = collections.deque(maxlen=60)
        self.ai_fn = ai_gate.gate     # replaceable (tests)
        self.ai_sync = False          # tests: run the AI call inline instead of in a background thread
        self.cands = []
        self.cool = {}
        self.status = "idle"
        self._cand_keys = []
        self._stop = False
        self._thread = None
        self._notes = {}
        self._snap = None
        self._hero_info = {}          # HERO: und -> {expiry, today}
        self._pend = {}               # SMART: und -> signal waiting for confirmation
        self._lean = {}               # SMART: und -> (kind, when) of the last entry (flip lock)
        self._load()
        if autostart:
            self.start_thread()

    # ------------------------------------------------------------------ plumbing
    def log(self, msg, level="info"):
        now = self.clock()
        row = {"t": now.strftime("%H:%M:%S"), "msg": msg, "level": level}
        self.logs.append(row)
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write("%s %s %s\n" % (now.strftime("%Y-%m-%d %H:%M:%S"), level.upper(), msg))
        except OSError:
            pass

    def _load(self):
        try:
            with open(self.pos_file, encoding="utf-8") as f:
                self.positions = {p["id"]: p for p in json.load(f)}
        except (OSError, ValueError):
            self.positions = {}
        try:
            with open(self.trades_file, encoding="utf-8") as f:
                self.trades = json.load(f)
        except (OSError, ValueError):
            self.trades = []
        if self.positions:
            self.log("Restored %d open position(s) from last run - monitoring them again." % len(self.positions), "warn")

    def _save_positions(self):
        tmp = self.pos_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(list(self.positions.values()), f, indent=1, default=str)
        os.replace(tmp, self.pos_file)

    def _save_trades(self):
        tmp = self.trades_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.trades[-600:], f, indent=1, default=str)
        os.replace(tmp, self.trades_file)

    def start_thread(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        self._thread = threading.Thread(target=self._loop, name="kp-options", daemon=True)
        self._thread.start()

    def shutdown(self):
        self._stop = True

    def _loop(self):
        while not self._stop:
            t0 = time.time()
            try:
                with self.lock:
                    self.tick()
            except Exception as e:                       # noqa: BLE001 - never let the loop die
                self.status = "error: %s" % e
                self.log("Engine error: %s" % e, "err")
                traceback.print_exc()
            time.sleep(max(0.2, 1.0 - (time.time() - t0)))

    # ------------------------------------------------------------------ public controls
    def start(self):
        with self.lock:
            cfg = config.load()
            self.running = True
            self.log("STARTED - mode %s, %s" % (cfg["mode"], "DRY RUN (paper)" if cfg["dry_run"] else "LIVE (real orders)"),
                     "warn" if not cfg["dry_run"] else "info")

    def stop(self):
        with self.lock:
            self.running = False
            self.log("STOPPED - no new entries. Open positions are still being managed.")

    def exit_position(self, pid, reason="Manual exit"):
        with self.lock:
            p = self.positions.get(pid)
            if not p:
                return False
            self._exit(p, reason)
            return True

    def exit_all(self, reason="Exit all"):
        with self.lock:
            for p in list(self.positions.values()):
                self._exit(p, reason)

    # ------------------------------------------------------------------ main tick
    def tick(self):
        cfg = config.load()
        cc = cfg["common"]
        now = self.clock()
        if not self.kio.connected():
            self.status = "Kite login needed"
            return
        if now.weekday() >= 5 and not getattr(self.kio, "FAKE", False):
            self.status = "weekend"
            return
        if not self.running and not self.positions:
            self.status = "idle (press Start)"
            return
        specs = self._specs(cfg) if self.running else []
        unds = sorted({s[0] for s in specs})
        skeys = {u: self._spot_key(u, cfg, now) for u in unds}
        keys = [k for k in skeys.values() if k]
        keys += ["%s:%s" % (p["exchange"], p["symbol"]) for p in self.positions.values()]
        keys += self._cand_keys
        if keys:
            self.q.update(self.kio.quote(keys))
        for u, k in skeys.items():
            sq = self.q.get(k) if k else None
            if sq and sq.get("last_price"):
                self.spot[u] = float(sq["last_price"])
                self._note_spot(u, self.spot[u], now)
        self._manage_positions(cfg, now)
        if self.running:
            self.status = "running - %s" % cfg["mode"]
            s_open, s_close = self._session(cfg)
            if not getattr(self.kio, "FAKE", False) and not (s_open <= mins(now) <= s_close):
                self.status = "running - market closed (waiting for %02d:%02d)" % (s_open // 60, s_open % 60)
            else:
                self._entries(cfg, specs, now)
        else:
            self.status = "stopped (managing %d open position(s))" % len(self.positions)

    # ------------------------------------------------------------------ candidate specs
    def _specs(self, cfg):
        m, out = cfg["mode"], []
        if m == "NORMAL":
            n = cfg["normal"]
            kinds = {"CALL": ["CE"], "PUT": ["PE"]}.get(str(n["side"]).upper(), ["CE", "PE"])
            out = [(n["underlying"].upper(), k, int(n.get("offset", 0))) for k in kinds]
        elif m == "AUTO":
            a = cfg["auto"]
            out = [(a["underlying"].upper(), k, int(o)) for o in a.get("offsets", [0]) for k in ("CE", "PE")]
        elif m == "MULTI":
            a = cfg["multi"]
            out = [(u.upper(), k, int(o)) for u in a["underlyings"] for o in a.get("offsets", [0]) for k in ("CE", "PE")]
        elif m == "PINE":
            a = cfg["pine"]
            out = [(u.upper(), k, int(a.get("offset", 0))) for u in a["underlyings"] for k in ("CE", "PE")]
        elif m == "HERO":
            out = [(u.upper(), "CE", 0) for u in cfg["hero"]["underlyings"]]      # only used to quote the spot prices
        elif m == "MCX":
            out = self._mcx_specs(cfg)
        if m in ("AUTO", "MULTI") and self._together(cfg):          # MCX scripts scanned alongside the equity symbols
            have = {s[0] for s in out}
            out += [s for s in self._mcx_specs(cfg) if s[0] not in have]
        return out

    @staticmethod
    def _mcx_specs(cfg):
        a = cfg["mcx"]
        kinds = {"CALL": ["CE"], "PUT": ["PE"]}.get(str(a.get("side", "BOTH")).upper(), ["CE", "PE"])
        return [(u.upper(), k, int(o)) for u in a["underlyings"] for o in a.get("offsets", [0]) for k in kinds]

    @staticmethod
    def _together(cfg):
        return bool(cfg["mcx"].get("together")) and cfg["mode"] in ("AUTO", "MULTI")

    def _cc_u(self, cfg, und):
        """Effective common settings for ONE underlying: MCX scripts always use the MCX box (premium range, size, timing...),
        also when they run together with AUTO / MULTI."""
        return self._eff(cfg, "MCX") if contracts.is_mcx(und) and cfg["mode"] != "MCX" else self._eff(cfg)

    @staticmethod
    def _open_min_u(cfg, und):
        return hm(cfg["mcx"]["session_open"]) if contracts.is_mcx(und) else (9 * 60 + 15)

    def _und_open(self, cfg, und, now):
        """Is this underlying's own market open now? (Only matters when equity + MCX run together.)"""
        if getattr(self.kio, "FAKE", False):
            return True
        if contracts.is_mcx(und):
            return hm(cfg["mcx"]["session_open"]) <= mins(now) <= hm(cfg["mcx"]["market_close"])
        return 9 * 60 + 15 <= mins(now) <= 15 * 60 + 30

    def _und_window(self, cfg, und, now):
        """Entry window of this underlying (its own start / end / avoid-window)."""
        cc = self._cc_u(cfg, und)
        if self._in_avoid(cc, now):
            return False
        return hm(cc["entry_start"]) <= mins(now) <= hm(cc["entry_end"])

    @staticmethod
    def _eff(cfg, mode=None):
        return config.effective(cfg, mode)

    @staticmethod
    def _session(cfg):
        """(open, close) in minutes of the day for the active mode (union of both markets when MCX runs together)."""
        mo, mc = hm(cfg["mcx"]["session_open"]), hm(cfg["mcx"]["market_close"])
        if cfg["mode"] == "MCX":
            return mo, mc
        if Engine._together(cfg):
            return min(9 * 60 + 15, mo), max(15 * 60 + 30, mc)
        return 9 * 60 + 15, 15 * 60 + 30

    def _spot_key(self, und, cfg, now):
        """Quote key of the price that decides the ATM strike. Index / stock: the spot. MCX: the future the option sits on."""
        if not contracts.is_mcx(und):
            return contracts.und_info(und)[0]
        c = self.fut.get(und)
        if c and c[0] == now.date():
            return c[1]
        if time.time() - self._fut_err.get(und, 0) < 30:
            return None
        try:
            cc = self._eff(cfg, "MCX")
            ch = self._chain(und, now)
            exp = ch.pick_expiry(cc["expiry"], now.date(), max(int(cc["min_days"]), 1 if cc["avoid_expiry_day"] else 0))
            fut = ch.underlying_future(exp) if exp else None
        except Exception as e:                           # noqa: BLE001
            self._fut_err[und] = time.time()
            self.log("MCX list error %s: %s" % (und, e), "err")
            return None
        key = ("MCX:%s" % fut["tradingsymbol"]) if fut else None
        if key is None:
            self._notes[und] = "no MCX option expiry / future found for %s" % und
        self.fut[und] = (now.date(), key)
        return key

    def _chain(self, und, now):
        c = self.chains.get(und)
        if c and c[0] == now.date():
            return c[1]
        spot_key, exch, _ = contracts.und_info(und)
        ch = contracts.Chain(und, self.kio.instruments(exch))
        self.chains[und] = (now.date(), ch)
        return ch

    def _candles(self, con, now, interval, budget, open_min=9 * 60 + 15):
        """Option candles for one contract. Refetch when a new candle bucket began (or every 30 s). budget = [n_left]."""
        im = INTERVAL_MIN.get(interval, 3)
        bucket = (mins(now) - open_min) // im
        h = self.hc.get(con["token"])
        stale = (h is None or h["bucket"] != bucket or h["date"] != now.date()
                 or (now - h["at"]).total_seconds() > 30)
        if stale and budget[0] > 0:
            budget[0] -= 1
            try:
                cs = self.kio.hist(con["token"], now - timedelta(days=5), now, interval)
                h = {"candles": cs, "bucket": bucket, "date": now.date(), "at": now}
                self.hc[con["token"]] = h
            except Exception as e:                       # noqa: BLE001
                self.log("History error %s: %s" % (con["symbol"], e), "err")
                if h is None:
                    return None
        return h["candles"] if h else None

    @staticmethod
    def _patch_live(candles, ltp, now, interval, open_min=9 * 60 + 15):
        im = INTERVAL_MIN.get(interval, 3)
        cs = [dict(c) for c in candles]
        start_min = (mins(now) - open_min) // im * im + open_min
        cur_start = now.replace(hour=start_min // 60, minute=start_min % 60, second=0, microsecond=0)
        if cs and cs[-1]["t"] >= cur_start:
            c = cs[-1]
            c["c"], c["h"], c["l"] = ltp, max(c["h"], ltp), min(c["l"], ltp)
        elif cs:
            cs.append({"t": cur_start, "o": ltp, "h": ltp, "l": ltp, "c": ltp, "v": 0.0})
        return cs

    # ------------------------------------------------------------------ analysis of every candidate
    def _evaluate(self, cfg, specs, now, hist_budget=4):
        cc0 = self._eff(cfg)
        interval = cc0["interval"]
        im = INTERVAL_MIN.get(interval, 3)
        budget = [hist_budget]
        rows, keys = [], []
        cc = cc0
        min_days = max(int(cc["min_days"]), 1 if cc["avoid_expiry_day"] else 0)
        for und, kind, off in specs:
            spot = self.spot.get(und)
            cc = self._cc_u(cfg, und)
            open_min = self._open_min_u(cfg, und)
            min_days = max(int(cc["min_days"]), 1 if cc["avoid_expiry_day"] else 0)
            row = {"und": und, "kind": kind, "offset": off, "block": None, "score": None}
            rows.append(row)
            if not self._und_open(cfg, und, now):
                row["block"] = "market closed"
                continue
            if not spot:
                row["block"] = "waiting for spot price"
                continue
            try:
                ch = self._chain(und, now)
                exp = ch.pick_expiry(cc["expiry"], now.date(), min_days)
                raw = ch.contract(exp, spot, kind, off) if exp else None
            except Exception as e:                       # noqa: BLE001
                row["block"] = "instrument list error: %s" % e
                continue
            if raw is None:
                row["block"] = "no %s contract (expiry %s)" % (kind, cc["expiry"])
                continue
            con = contracts.clean(raw)
            if contracts.is_mcx(und):
                con["lot"], row["lot_warn"] = self._mcx_lot(und, con["lot"], cfg)
            row.update(con)
            key = "%s:%s" % (con["exchange"], con["symbol"])
            keys.append(key)
            q = self.q.get(key)
            if not q or not q.get("last_price"):
                row["block"] = "waiting for option price"
                continue
            ltp = float(q["last_price"])
            depth = q.get("depth") or {}
            bid = (depth.get("buy") or [{}])[0].get("price") or 0.0
            ask = (depth.get("sell") or [{}])[0].get("price") or 0.0
            row.update(ltp=ltp, bid=bid, ask=ask, spot=spot, lot_cost=round(ltp * con["lot"]), vol=q.get("volume"), oi=q.get("oi"),
                       spread=round((ask - bid) / ask * 100, 2) if bid > 0 and ask > 0 else None)
            raw_cs = self._candles(con, now, interval, budget, open_min)
            if not raw_cs:
                row["block"] = "loading candles"
                continue
            cs = self._patch_live(raw_cs, ltp, now, interval, open_min)
            an = sig.analyze(cs, cc)
            row["an"] = an
            row["raw_candles"] = raw_cs
            if an.get("ok"):
                row.update(score=an["score"], rsi=an["rsi"], er=an["er"], atr=an["atr"], signals=an["signals"])
                row["reach"] = sig.reach(cs, int(cc.get("reach_hold_bars", 8)), int(cc.get("reach_lookback", 40)))
            else:
                row["block"] = an["why"]
                continue
            if ltp < cc["min_premium"] or ltp > cc["max_premium"]:
                row["block"] = "premium %.2f outside %s-%s" % (ltp, cc["min_premium"], cc["max_premium"])
            elif row["spread"] is not None and row["spread"] > cc["max_spread_pct"]:
                row["block"] = "spread %.1f%% > %.1f%%" % (row["spread"], cc["max_spread_pct"])
            elif not an["trend_ok"]:
                row["block"] = ("no clean breakout uptrend in premium (EMA / breakout / chop filter)" if an.get("gate", "STRICT") == "STRICT"
                                else "premium not trending up yet (EMA / RSI momentum)")
                row["soft"] = True                         # analysis-quality block (ignored by Pine "Open-break only")
            elif an["overstretched"]:
                row["block"] = "RSI overstretched (%.0f)" % an["rsi"]
                row["soft"] = True
            else:
                self._extra_filters(row, cc, cs, kind, und, now)
        self._prefetch(cfg, specs, now, interval, budget, keys)
        self._cand_keys = keys
        return rows

    def _extra_filters(self, row, cc, cs, kind, und, now):
        """Optional accuracy filters - applied only after the normal signal passed. Each one sets a soft block."""
        mv = int(cc.get("min_opt_volume", 0) or 0)
        mo = int(cc.get("min_opt_oi", 0) or 0)
        if mv and (row.get("vol") or 0) < mv:
            row["block"], row["soft"] = "option volume %s < %s (illiquid)" % (row.get("vol") or 0, mv), True
        elif mo and (row.get("oi") or 0) < mo:
            row["block"], row["soft"] = "option OI %s < %s (illiquid)" % (row.get("oi") or 0, mo), True
        elif cc.get("spot_confirm"):
            m = int(cc.get("spot_confirm_mins", 3))
            mv_pct = self._spot_move(und, m, now)
            th = float(cc.get("spot_confirm_pct", 0.01))
            if mv_pct is not None and ((kind == "CE" and mv_pct < th) or (kind == "PE" and mv_pct > -th)):
                row["block"] = "%s not moving the %s way (%+.3f%% in %dm, need %s%.3f%%)" % (
                    und, "up" if kind == "CE" else "down", mv_pct, m, "+" if kind == "CE" else "-", th)
                row["soft"] = True
        if not row["block"] and float(cc.get("max_chase_pct", 0) or 0) > 0:
            up = sig.recent_low_gain_pct(cs, int(cc.get("chase_bars", 10)))
            if up > float(cc["max_chase_pct"]):
                row["block"], row["soft"] = "already +%.0f%% off the recent low - not chasing (limit %.0f%%)" % (up, float(cc["max_chase_pct"])), True
        if not row["block"] and float(cc.get("rr_min", 0) or 0) > 0:
            plan = self._plan(row["ltp"], row.get("atr") or 0.0, row["tick"], cc, row.get("reach"))
            if not plan["feasible"]:
                if str(cc.get("target_mode", "RR")).upper() == "PCT" and plan["rr"] < float(cc["rr_min"]):
                    row["block"] = "target +%.0f%% is only 1:%.1f of the stop-loss (need 1:%s)" % (float(cc["target_pct"]), plan["rr"], cc["rr_min"])
                else:
                    row["block"] = "1:%s target not reachable: needs +%.1f, recent moves ~+%.1f" % (cc["rr_min"], plan["need"], plan["reach"] or 0)
                row["soft"] = True

    def _prefetch(self, cfg, specs, now, interval, budget, keys):
        """Speed: with spare history budget, keep the candles of the neighbouring strikes warm, so when the ATM strike
        moves the new contract can be judged immediately instead of waiting for its history to load."""
        if not self._eff(cfg).get("prefetch", True) or budget[0] < 3 or cfg["mode"] in ("PINE", "HERO"):
            return
        seen = set()
        try:
            for und, kind, off in specs:
                spot = self.spot.get(und)
                if not spot or not self._und_open(cfg, und, now):
                    continue
                cc = self._cc_u(cfg, und)
                open_min = self._open_min_u(cfg, und)
                min_days = max(int(cc["min_days"]), 1 if cc["avoid_expiry_day"] else 0)
                ch = self._chain(und, now)
                exp = ch.pick_expiry(cc["expiry"], now.date(), min_days)
                for o in (off - 1, off + 1):
                    raw = ch.contract(exp, spot, kind, o) if exp else None
                    if raw is None or raw["tradingsymbol"] in seen or budget[0] < 3:
                        continue
                    seen.add(raw["tradingsymbol"])
                    self._candles(contracts.clean(raw), now, interval, budget, open_min)
        except Exception:                                   # noqa: BLE001 - prefetch is a pure optimisation
            pass

    # ------------------------------------------------------------------ entry decisions
    def _gate(self, und, cfg, now, mode_max_open, symbol=None):
        cc = self._cc_u(cfg, und)
        mcx_u = contracts.is_mcx(und) and cfg["mode"] != "MCX"
        g = "MCX" if (mcx_u or cfg["mode"] == "MCX") else "EQ"
        if mcx_u:
            mode_max_open = int(cfg["mcx"].get("max_open", 2))
        # AUTO with "max positions" > 1 may hold several contracts of the same underlying (a new pick on a different
        # strike / side); the cooldown and the 'already open' rule are then per CONTRACT instead of per underlying.
        multi_same = cfg["mode"] == "AUTO" and not mcx_u and mode_max_open > 1 and symbol is not None
        key = symbol if multi_same else und
        if self.cool.get(key) and now < self.cool[key]:
            return "cooldown after last trade on %s" % key
        if multi_same:
            if any(p["symbol"] == symbol for p in self.positions.values()):
                return "%s already has an open position" % symbol
        elif any(p["und"] == und for p in self.positions.values()):
            return "%s already has an open position" % und
        if sum(1 for p in self.positions.values() if grp(p.get("mode")) == g) >= mode_max_open:
            return "max open positions (%d) reached" % mode_max_open
        if self._trades_today(now, g) >= int(cc["max_trades_day"]):
            return "max trades per day reached"
        if self._day_pnl(now, g) <= -abs(float(cc["daily_max_loss"])):
            return "daily max loss reached"
        return None

    def _entries(self, cfg, specs, now):
        if cfg["mode"] == "HERO":
            return self._hero_entries(cfg, now)
        cc, mode = self._eff(cfg), cfg["mode"]
        rows = self._evaluate(cfg, specs, now)
        need = sig.needed(cc)
        picks = []
        in_win = hm(cc["entry_start"]) <= mins(now) <= hm(cc["entry_end"])
        avoid = self._in_avoid(cc, now) if mode != "PINE" else None
        if avoid:
            in_win = False
        together = self._together(cfg)
        if together:                                       # each underlying has its own entry window
            in_win = any(self._und_window(cfg, u, now) for u in {s[0] for s in specs})
        max_open = self._max_open(cfg)
        if mode == "PINE":
            p = cfg["pine"]
            im = INTERVAL_MIN.get(cc["interval"], 3)
            in_win = 9 * 60 + 16 <= mins(now) <= 9 * 60 + 15 + int(p["entry_bars"]) * im
            self._pine_eval(cfg, rows, need)
        by_und = collections.defaultdict(list)
        for r in rows:
            by_und[r["und"]].append(r)
        # AUTO with several positions allowed: a contract we already hold is not picked again (a NEW contract is)
        held = {p["symbol"] for p in self.positions.values()} if mode == "AUTO" and max_open > 1 else ()
        for und, cl in by_und.items():
            if mode == "PINE":
                best = self._pine_pick(cfg, cl)
            else:
                best = self._edge_pick(cl, need, self._mode_edge(cfg), held)
                best = self._stabilize(und, best, cl, cfg, now)
            if best:
                picks.append(best)
        picks.sort(key=lambda r: (r.get("score") or 0, r.get("er") or 0), reverse=True)
        for r in rows:                                    # snapshot for the page (no heavy fields)
            r["need"] = need
        self.cands = [{k: v for k, v in r.items() if k not in ("an", "raw_candles")} for r in rows]
        self._rows_full = rows
        self.ideas = self._make_ideas(cfg, rows, picks, need, now)
        if not in_win:
            self.status = ("running - no new entries in the avoid window (%s)" % avoid) if avoid else \
                "running - outside entry window (%s-%s)" % (cc["entry_start"], cc["entry_end"])
            return
        for r in picks:
            if together and not self._und_window(cfg, r["und"], now):
                continue
            why = self._gate(r["und"], cfg, now, max_open, r["symbol"])
            if why:
                self._notes[r["und"]] = why
                continue
            if not self._ai_ok(r, cfg, now):
                continue
            self._lean[r["und"]] = (r["kind"], now)
            self._enter(r, cfg, now)

    # ------------------------------------------------------------------ optional Google AI second opinion
    def _ai_payload(self, r, cfg, now):
        skey = self._spot_key(r["und"], cfg, now)
        sq = self.q.get(skey) if skey else None
        prev = ((sq or {}).get("ohlc") or {}).get("close")
        spot = self.spot.get(r["und"])
        try:
            dte = (datetime.strptime(r["expiry"], "%Y-%m-%d").date() - now.date()).days
        except (KeyError, ValueError):
            dte = None
        ctx = {"mode": cfg["mode"], "time": now.strftime("%H:%M"), "dte": dte, "spot": spot,
               "chg": (spot / prev - 1) * 100 if spot and prev else None, "opp_score": r.get("opp_score")}
        return ai_gate.build_payload(r, ctx)

    def _ai_ok(self, r, cfg, now):
        """True = go ahead with this entry. AI can only SKIP a trade the rules already chose. Never blocks the loop:
        the Google call runs in a background thread and the entry waits (max timeout+4 s) for its answer."""
        a = cfg["ai"]
        if not a.get("enabled"):
            return True
        und = r["und"]
        im = INTERVAL_MIN.get(cfg["common"]["interval"], 3)
        key = (r["symbol"], now.date().isoformat(), (mins(now) - self._open_min_u(cfg, und) if self._together(cfg) else mins(now) - self._session(cfg)[0]) // im)
        ent = self.ai_cache.get(key)
        if ent is None:
            if len(self.ai_cache) > 300:
                for k in list(self.ai_cache)[:150]:
                    self.ai_cache.pop(k, None)
            ent = {"st": "pending", "t": time.time(), "res": None, "logged": False}
            self.ai_cache[key] = ent
            payload, acfg = self._ai_payload(r, cfg, now), dict(a)

            def work():
                try:
                    res = self.ai_fn(payload, acfg)
                except Exception as ex:                  # noqa: BLE001 - any AI problem is handled by the on_error rule
                    res = {"error": str(ex)[:160]}
                if ent["st"] == "pending":
                    ent["res"], ent["st"] = res, "done"
            if self.ai_sync:
                work()
            else:
                threading.Thread(target=work, name="kp-ai", daemon=True).start()
        if ent["st"] == "pending":
            if time.time() - ent["t"] > float(a.get("timeout_s", 6)) + 4:
                ent["res"], ent["st"] = {"error": "AI timed out"}, "done"
            else:
                self._notes[und] = "waiting for AI second opinion..."
                return False
        res = ent["res"] or {"error": "no answer"}
        if not ent["logged"]:
            ent["logged"] = True
            self.ai_log.append({"t": now.strftime("%H:%M:%S"), "symbol": r["symbol"], "und": und, "kind": r["kind"],
                                "verdict": res.get("verdict") or "ERROR", "confidence": res.get("confidence"),
                                "reason": res.get("reason") or res.get("error", "")})
            self.log("AI %s %s: %s %s%% - %s" % (r["symbol"], "ERROR" if res.get("error") else "verdict",
                     res.get("verdict", "-"), res.get("confidence", "-"), res.get("reason") or res.get("error", "")),
                     "warn" if res.get("error") else "info")
        if res.get("error"):
            if str(a.get("on_error", "ALLOW")).upper() == "ALLOW":
                r["ai"] = {"verdict": "N/A", "confidence": None, "reason": "AI error: %s" % res["error"]}
                return True
            self._notes[und] = "AI error - entry skipped (%s)" % res["error"]
            return False
        if res["verdict"] == "APPROVE" and res["confidence"] >= int(a.get("min_confidence", 60)):
            r["ai"] = res
            return True
        self._notes[und] = "AI skipped %s: %s (%d%%)" % (r["symbol"], res.get("reason", ""), res["confidence"])
        return False

    @staticmethod
    def _mode_edge(cfg):
        m = cfg["mode"]
        return 0 if m == "NORMAL" else int(cfg[{"AUTO": "auto", "MCX": "mcx"}.get(m, "multi")].get("min_edge", 1))

    @staticmethod
    def _max_open(cfg):
        m = cfg["mode"]
        if m == "PINE":
            return int(cfg["pine"].get("max_open", 1))
        return int(cfg[m.lower()].get("max_open", 1)) if m in ("AUTO", "MULTI", "MCX", "HERO") else 1

    def _note_spot(self, und, price, now):
        h = self.spot_hist.setdefault(und, collections.deque(maxlen=1500))
        if not h or h[-1][1] != price or (now - h[-1][0]).total_seconds() >= 20:
            h.append((now, price))

    def _spot_move(self, und, minutes, now):
        """% move of the underlying over the last `minutes` (None when the recorded history is too short)."""
        h = self.spot_hist.get(und)
        if not h or len(h) < 2:
            return None
        target = now - timedelta(minutes=minutes)
        old = None
        for t, p in h:
            if t <= target:
                old = (t, p)
            else:
                break
        if old is None or (target - old[0]).total_seconds() > 90:       # no sample near the start of the window yet
            return None
        return (h[-1][1] / old[1] - 1) * 100 if old[1] else None

    @staticmethod
    def _in_avoid(cc, now):
        for part in str(cc.get("avoid_windows") or "").replace(";", ",").split(","):
            if "-" in part:
                a, b = part.strip().split("-", 1)
                try:
                    if hm(a.strip()) <= mins(now) < hm(b.strip()):
                        return part.strip()
                except (ValueError, IndexError):
                    continue
        return None

    def _profit_cap(self, cc, now):
        """Profit lock: a NEW trade may lose at most profit_lock_pct % of the profit already BOOKED today (all trades).
        None = off, or nothing booked yet (then the normal stop-loss is the only limit)."""
        pct = float(cc.get("profit_lock_pct", 0) or 0)
        if pct <= 0:
            return None
        booked = sum(t["pnl"] for t in self._today_trades(now))
        return booked * pct / 100.0 if booked > 0 else None

    @staticmethod
    def _mcx_lot(und, kite_lot, cfg):
        """-> (lot used, warning). An explicit override wins. Otherwise Kite's lot size is used, and a warning is
        raised when it differs from the usual MCX contract size (LIVE entries are then refused, see _enter)."""
        try:
            ov = int((cfg["mcx"].get("lot_override") or {}).get(und, 0) or 0)
        except (TypeError, ValueError):
            ov = 0
        if ov > 0:
            return ov, None
        ref = contracts.MCX_REF_LOT.get(und)
        if ref and kite_lot != ref:
            return kite_lot, ("Using Kite's lot size %d (usual MCX %d for %s). If your Kite order window shows a different "
                              "quantity per lot, set 'Lot size override' in Settings -> MCX" % (kite_lot, ref, und))
        return kite_lot, None

    @staticmethod
    def _plan(entry, atr_abs, tick, cc, reach=None):
        """Stop-loss + square-off target for an entry, and which of the 1:1.5 / 1:2 / 1:2.5 targets look reachable.
        target_mode RR  -> target = rr x risk | PCT -> +target_pct % of the money invested | AUTO -> the biggest reachable
        ladder target (at least rr_min). `feasible` = a target of at least rr_min looks reachable (always True when rr_min = 0
        or when there is not enough data to judge)."""
        slp, R, sl, tgt0 = Engine._risk(entry, atr_abs, tick, cc)
        ladder = [{"rr": k, "price": round_tick(entry + k * R, tick, "up"), "need": round(k * R, 2),
                   "ok": reach is None or reach >= k * R} for k in (1.5, 2.0, 2.5)]
        rr_min = float(cc.get("rr_min", 0) or 0)
        mode = str(cc.get("target_mode", "RR")).upper()
        tgt, rr_used = tgt0, float(cc["rr"])
        if mode == "PCT":
            dist = entry * float(cc.get("target_pct", 15)) / 100.0
            tgt, rr_used = round_tick(entry + dist, tick, "up"), (dist / R if R > 0 else 0.0)
        elif mode == "AUTO":
            good = [x for x in ladder if x["ok"] and x["rr"] >= max(rr_min, 1.5)]
            pick = max(good, key=lambda x: x["rr"]) if good else ladder[0]
            tgt, rr_used = pick["price"], pick["rr"]
        if not cc.get("target_on", True):
            tgt = None
        need_dist = rr_min * R
        if rr_min <= 0:
            feasible = True
        elif mode == "PCT":
            feasible = rr_used >= rr_min and (reach is None or reach >= entry * float(cc.get("target_pct", 15)) / 100.0)
        else:
            feasible = reach is None or reach >= need_dist
        return {"slp": slp, "R": R, "sl": sl, "tgt": tgt, "rr": round(rr_used, 2), "ladder": ladder,
                "feasible": feasible, "need": round(need_dist, 2), "reach": None if reach is None else round(reach, 2)}

    def _chg(self, und, cfg, now):
        """Day change % of the underlying (spot / MCX future) from the last quote."""
        skey = self._spot_key(und, cfg, now)
        sq = self.q.get(skey) if skey else None
        prev = ((sq or {}).get("ohlc") or {}).get("close")
        spot = self.spot.get(und)
        return round((spot / prev - 1) * 100, 2) if spot and prev else None

    def _make_ideas(self, cfg, rows, picks, need, now):
        """For each underlying: the option that LOOKS best right now (CALL or PUT) with the entry / SL / target the bot
        would use. state READY = all rules pass (bot buys it when window + limits allow); BUILDING = one short of the
        score and clearly ahead of the opposite side; WEAK = no real signal yet (levels are only 'if you bought now')."""
        if cfg["mode"] == "PINE":
            return []
        picked = {p["symbol"] for p in picks}
        by = collections.defaultdict(list)
        for r in rows:
            by[r["und"]].append(r)
        out = []
        for und, cl in by.items():
            el = [r for r in cl if r.get("score") is not None and r.get("ltp") and r.get("an")
                  and (not r["block"] or r.get("soft"))]            # hard blocks (premium range, spread, no data) are not offered
            if not el:
                out.append({"und": und, "state": "NONE", "why": next((r["block"] for r in cl if r["block"]), "waiting for data"),
                            "chg": self._chg(und, cfg, now)})
                continue
            best = max(el, key=lambda r: (r["score"], r.get("er") or 0))
            opp = max([r["score"] for r in cl if r["kind"] != best["kind"] and r.get("score") is not None] or [0])
            if best["symbol"] in picked:
                state = "READY"
            elif best["score"] >= need - 1 and best["score"] - opp >= 1:
                state = "BUILDING"
            else:
                state = "WEAK"
            ref = best["ask"] if best.get("ask") else best["ltp"]
            pl = self._plan(ref, best.get("atr") or 0.0, best["tick"], self._cc_u(cfg, und), best.get("reach"))
            slp, R, sl, tgt = pl["slp"], pl["R"], pl["sl"], pl["tgt"]
            lot = best["lot"]
            out.append({"und": und, "state": state, "rr": pl["rr"], "ladder": pl["ladder"], "reach": pl["reach"],
                        "feasible": pl["feasible"], "lot_warn": best.get("lot_warn"), "symbol": best["symbol"], "kind": best["kind"], "strike": best["strike"],
                        "expiry": best["expiry"], "ltp": round(best["ltp"], 2), "entry": round(ref, 2), "sl": sl,
                        "sl_pct": round(slp, 1), "target": tgt,
                        "tgt_pct": round((tgt / ref - 1) * 100, 1) if tgt else None,
                        "risk_lot": round((ref - sl) * lot), "reward_lot": round((tgt - ref) * lot) if tgt else None,
                        "lot": lot, "lot_cost": round(ref * lot), "score": best["score"], "need": need, "opp": opp,
                        "missing": [n for n, v in (best["an"].get("signals") or {}).items() if not v],
                        "block": best["block"], "chg": self._chg(und, cfg, now)})
        order = {"READY": 0, "BUILDING": 1, "WEAK": 2, "NONE": 3}
        out.sort(key=lambda i: (order[i["state"]], -(i.get("score") or 0)))
        return out

    def take_idea(self, symbol):
        """DRY RUN only: open a paper trade on an idea right now (to see entry / SL / target / exit working)."""
        with self.lock:
            cfg = config.load()
            if not cfg["dry_run"]:
                return {"ok": False, "error": "Ye button sirf DRY RUN me chalta hai (real paisa nahi lagta)."}
            now = self.clock()
            r = next((x for x in self._rows_full if x.get("symbol") == symbol and x.get("ltp")), None)
            if not r:
                return {"ok": False, "error": "Idea purana ho gaya - Analyze now dabao aur dobara try karo."}
            why = self._gate(r["und"], cfg, now, self._max_open(cfg), r["symbol"])
            if why:
                return {"ok": False, "error": why}
            r = dict(r)
            r["why"] = "manual PAPER trade from idea (score %s/%s)" % (r.get("score"), r.get("max", 7))
            before = len(self.positions)
            self._notes.pop(r["und"], None)
            self._enter(r, cfg, now)
            if len(self.positions) > before:
                return {"ok": True}
            return {"ok": False, "error": self._notes.get(r["und"]) or "paper entry did not fill"}

    def _stabilize(self, und, best, cl, cfg, now):
        """SMART AUTO: a signal must survive `confirm_s` seconds (kills one-tick spikes) and, right after we bought one side,
        the OPPOSITE side needs a clearly bigger edge for `flip_lock_min` minutes (no CALL/PUT ping-pong)."""
        cc = self._cc_u(cfg, und)
        confirm = float(cc.get("confirm_s", 6) or 0)
        lock = float(cc.get("flip_lock_min", 6) or 0)
        if best is None:
            self._pend.pop(und, None)
            return None
        if confirm > 0:
            p = self._pend.get(und)
            if not p or p["symbol"] != best["symbol"]:
                self._pend[und] = {"symbol": best["symbol"], "t": now}
                best["note"] = "signal found - confirming (%ds)" % confirm
                return None
            if (now - p["t"]).total_seconds() < confirm:
                return None
        last = self._lean.get(und)
        if lock > 0 and last and last[0] != best["kind"] and (now - last[1]).total_seconds() < lock * 60:
            gap = best["score"] - (best.get("opp_score") or 0)
            if gap < self._mode_edge(cfg) + 1:
                best["note"] = "just traded the other side - flip needs a bigger edge"
                return None
        return best

    @staticmethod
    def _edge_pick(cl, need, min_edge, skip=()):
        ok = [r for r in cl if not r["block"] and r["score"] is not None and r["score"] >= need and r["symbol"] not in skip]
        if not ok:
            return None
        best = max(ok, key=lambda r: (r["score"], r["er"]))
        opp = [r["score"] for r in cl if r["kind"] != best["kind"] and r["score"] is not None]
        if best["score"] - (max(opp) if opp else 0) < min_edge:
            best["note"] = "no clear edge vs opposite side"
            return None
        best["opp_score"] = max(opp) if opp else None
        best["why"] = "premium score %d/7 (need %d)%s" % (best["score"], need, ", edge +%d" % (best["score"] - (max(opp) if opp else 0)))
        return best

    def _pine_eval(self, cfg, rows, need):
        cc, p = cfg["common"], cfg["pine"]
        im = INTERVAL_MIN.get(cc["interval"], 3)
        for r in rows:
            r["brk"] = False
            if "raw_candles" not in r:
                continue
            o = sig.orb(r["raw_candles"], p["orb_minutes"], im)
            if not o:
                r["block"] = r["block"] or "no 9:15 candle for this contract"
                continue
            prev = r["raw_candles"][-2]["c"] if len(r["raw_candles"]) > 1 else None
            ok, lvl = sig.pine_break(r["ltp"], o["open"], r["tick"], p, prev)
            r.update(orb_open=o["open"], orb_hi=o["hi"], break_level=round(lvl, 2), brk=ok,
                     brk_pct=round((r["ltp"] / o["open"] - 1) * 100, 2))

    def _pine_pick(self, cfg, cl):
        p, cc = cfg["pine"], cfg["common"]
        mode, need = p["entry_mode"], sig.needed(cc)
        elig = []
        for r in cl:
            if "ltp" not in r:
                continue
            blk = r["block"]
            if mode == "Open-break only" and blk and (r.get("soft") or blk.startswith("only")):
                blk = None                                # score / trend filters are not used in this mode
            if blk:
                continue
            has_score = r["score"] is not None and r["score"] >= need
            if mode == "AUTO score only (instant)":
                good = has_score
            elif mode == "Open-break only":
                good = r["brk"]
            else:
                good = r["brk"] and has_score
            if not good:
                continue
            if p.get("require_opposite_weak", True):
                opp = [o for o in cl if o["kind"] != r["kind"] and o.get("orb_open")]
                if any(o["ltp"] > o["orb_open"] for o in opp):
                    r["note"] = "opposite option also above its open"
                    continue
            elig.append(r)
        if not elig:
            return None
        best = max(elig, key=lambda r: r.get("brk_pct", 0))
        best["why"] = "Pine break %+.1f%% over 9:15 open (%s)" % (best.get("brk_pct", 0), mode)
        return best

    # ------------------------------------------------------------------ HERO-ZERO: cheap options on expiry day
    @staticmethod
    def _hero_risk(entry, tick, h):
        """Fixed % stop on the premium; target = entry x target_x (2x / 3x / 5x ...). -> (sl %, R, sl, target)"""
        slp = float(h["sl_pct"])
        r = entry * slp / 100.0
        return slp, round(r, 2), round_tick(entry - r, tick, "down"), round_tick(entry * float(h["target_x"]), tick, "up")

    @staticmethod
    def _hero_stale(cfg, p, ltp, now):
        """A cheap option that has not moved for N minutes is just decaying - leave instead of waiting for zero."""
        n = float(cfg["hero"].get("stale_exit_min", 0) or 0)
        if n <= 0:
            return False
        try:
            held = (now - datetime.fromisoformat(p["entry_time"])).total_seconds() / 60.0
        except (KeyError, ValueError):
            return False
        return held >= n and ltp <= p["entry"] * 1.05

    def _hero_evaluate(self, cfg, now, hist_budget=4):
        """Scan CALL / PUT strikes from ATM to `scan_steps` OTM of every chosen underlying. Only strikes whose premium is
        inside the low-premium band (and liquid / affordable) get their candles fetched and scored."""
        h, cc = cfg["hero"], self._eff(cfg)
        interval, open_min = cc["interval"], self._session(cfg)[0]
        budget = [hist_budget]
        kinds = {"CALL": ["CE"], "PUT": ["PE"]}.get(str(h["side"]).upper(), ["CE", "PE"])
        rows, keys, info = [], [], {}
        for und in h["underlyings"]:
            und = und.upper()
            try:
                ch = self._chain(und, now)
                exp = ch.pick_expiry("NEAR", now.date(), 0)
            except Exception as e:                       # noqa: BLE001
                rows.append({"und": und, "kind": "-", "score": None, "block": "instrument list error: %s" % e})
                continue
            today = bool(exp) and exp == now.date()
            info[und] = {"expiry": exp.isoformat() if exp else None, "today": today}
            if exp is None:
                rows.append({"und": und, "kind": "-", "score": None, "block": "no expiry found"})
                continue
            if h["only_expiry_day"] and not today:
                rows.append({"und": und, "kind": "-", "score": None, "expiry": exp.isoformat(),
                             "block": "not an expiry day (next expiry %s) - Hero-Zero waits" % exp.isoformat()})
                continue
            spot = self.spot.get(und)
            if not spot:
                rows.append({"und": und, "kind": "-", "score": None, "block": "waiting for spot price"})
                continue
            outside = 0
            for kind in kinds:
                for step in range(0, int(h["scan_steps"]) + 1):
                    raw = ch.contract(exp, spot, kind, -step)
                    if raw is None:
                        break
                    con = contracts.clean(raw)
                    row = {"und": und, "kind": kind, "offset": -step, "block": None, "score": None}
                    row.update(con)
                    key = "%s:%s" % (con["exchange"], con["symbol"])
                    keys.append(key)
                    q = self.q.get(key)
                    if not q or not q.get("last_price"):
                        row["block"] = "waiting for option price"
                        rows.append(row)
                        continue
                    ltp = float(q["last_price"])
                    depth = q.get("depth") or {}
                    bid = (depth.get("buy") or [{}])[0].get("price") or 0.0
                    ask = (depth.get("sell") or [{}])[0].get("price") or 0.0
                    ref = ask or ltp
                    vol = int(q.get("volume") or 0)
                    row.update(ltp=ltp, bid=bid, ask=ask, spot=spot, volume=vol, lot_cost=round(ref * con["lot"]),
                               spread=round((ask - bid) / ask * 100, 2) if bid > 0 and ask > 0 else None)
                    if ltp < float(cc["min_premium"]) or ltp > float(cc["max_premium"]):
                        outside += 1                      # not a low-premium candidate: not listed (keeps the table short)
                        continue
                    if ref * con["lot"] > float(cc["budget"]):
                        row["block"] = "1 lot = Rs%d > budget Rs%d" % (ref * con["lot"], float(cc["budget"]))
                    elif row["spread"] is not None and row["spread"] > float(cc["max_spread_pct"]):
                        row["block"] = "spread %.1f%% > %.1f%%" % (row["spread"], float(cc["max_spread_pct"]))
                    elif vol < int(h["min_volume"]):
                        row["block"] = "volume %s < %s" % (format(vol, ","), format(int(h["min_volume"]), ","))
                    else:
                        raw_cs = self._candles(con, now, interval, budget, open_min)
                        if not raw_cs:
                            row["block"] = "loading candles"
                        else:
                            hc = sig.hero_check(self._patch_live(raw_cs, ltp, now, interval, open_min), h)
                            row["an"], row["raw_candles"] = hc, raw_cs
                            if not hc["ok"]:
                                row["block"] = hc["why"]
                            else:
                                row.update(score=hc["score"], max=hc["max"], signals=hc["signals"], atr=hc["atr"],
                                           brk_pct=hc["gain_pct"], surge=hc["surge"], rsi=hc["rsi"], er=hc["er"])
                                if hc["overrun"]:
                                    row["block"], row["soft"] = "already +%d%% from the day low - too late" % hc["gain_pct"], True
                                elif not hc["trend_ok"]:
                                    row["block"], row["soft"] = "no breakout + volume surge yet", True
                    rows.append(row)
            if outside:
                self._notes[und] = "%d strikes outside the Rs%g-%g premium band (hidden)" % (outside, float(cc["min_premium"]), float(cc["max_premium"]))
        self._cand_keys = keys
        self._hero_info = info
        return rows

    @staticmethod
    def _hero_picks(h, rows, need, held=()):
        by = collections.defaultdict(list)
        for r in rows:
            by[r["und"]].append(r)
        picks = []
        for und, cl in by.items():
            ok = [r for r in cl if not r["block"] and r.get("score") is not None and r["score"] >= need and r["symbol"] not in held]
            if not ok:
                continue
            best = max(ok, key=lambda r: (r["score"], r.get("surge") or 0, -r["ltp"]))
            opp = max([r["score"] for r in cl if r["kind"] != best["kind"] and r.get("score") is not None] or [0])
            if best["score"] - opp < int(h["min_edge"]):
                best["note"] = "no clear edge vs opposite side"
                continue
            best["opp_score"] = opp
            best["why"] = "HERO-ZERO: premium %.2f, breakout + %.1fx volume, +%d%% from day low, score %d/%d, target %.1fx" % (
                best["ltp"], best.get("surge") or 0, best.get("brk_pct") or 0, best["score"], best.get("max", 6), float(h["target_x"]))
            picks.append(best)
        picks.sort(key=lambda r: (r["score"], r.get("surge") or 0), reverse=True)
        return picks

    def _hero_snapshot(self, cfg, rows, picks, need, now):
        for r in rows:
            r["need"] = need
        self.cands = [{k: v for k, v in r.items() if k not in ("an", "raw_candles")} for r in rows]
        self._rows_full = rows
        self.ideas = self._hero_ideas(cfg, rows, picks, need, now)

    def _hero_entries(self, cfg, now):
        h = cfg["hero"]
        rows = self._hero_evaluate(cfg, now)
        need = int(h["min_score"])
        picks = self._hero_picks(h, rows, need, {p["symbol"] for p in self.positions.values()})
        self._hero_snapshot(cfg, rows, picks, need, now)
        if h["only_expiry_day"] and self._hero_info and not any(v["today"] for v in self._hero_info.values()):
            self.status = "running - HERO-ZERO waits (no expiry today for your symbols)"
            return
        if not hm(h["entry_start"]) <= mins(now) <= hm(h["entry_end"]):
            self.status = "running - HERO-ZERO outside entry window (%s-%s)" % (h["entry_start"], h["entry_end"])
            return
        for r in picks:
            why = self._gate(r["und"], cfg, now, int(h["max_open"]), r["symbol"])
            if why:
                self._notes[r["und"]] = why
                continue
            if not self._ai_ok(r, cfg, now):
                continue
            self._enter(r, cfg, now)

    def _hero_analyze(self, cfg, now):
        h = cfg["hero"]
        self._hero_evaluate(cfg, now, 0)
        self.q.update(self.kio.quote(self._cand_keys))
        rows = self._hero_evaluate(cfg, now, 60)
        need = int(h["min_score"])
        picks = self._hero_picks(h, rows, need)
        self._hero_snapshot(cfg, rows, picks, need, now)
        return {"ok": True, "cands": self.cands, "ideas": self.ideas}

    def _hero_ideas(self, cfg, rows, picks, need, now):
        h = cfg["hero"]
        picked = {p["symbol"] for p in picks}
        by = collections.defaultdict(list)
        for r in rows:
            by[r["und"]].append(r)
        out = []
        for und, cl in by.items():
            el = [r for r in cl if r.get("score") is not None and r.get("ltp") and (not r["block"] or r.get("soft"))]
            if not el:
                out.append({"und": und, "state": "NONE", "why": next((r["block"] for r in cl if r["block"]), "waiting for data"),
                            "chg": self._chg(und, cfg, now)})
                continue
            best = max(el, key=lambda r: (r["score"], r.get("surge") or 0))
            opp = max([r["score"] for r in cl if r["kind"] != best["kind"] and r.get("score") is not None] or [0])
            state = "READY" if best["symbol"] in picked else ("BUILDING" if best["score"] >= need - 1 and best["score"] - opp >= 1 else "WEAK")
            ref = best["ask"] or best["ltp"]
            slp, R, sl, tgt = self._hero_risk(ref, best["tick"], h)
            lot = best["lot"]
            out.append({"und": und, "state": state, "symbol": best["symbol"], "kind": best["kind"], "strike": best["strike"],
                        "expiry": best["expiry"], "ltp": round(best["ltp"], 2), "entry": round(ref, 2), "sl": sl,
                        "sl_pct": round(slp, 1), "target": tgt, "tgt_pct": round((tgt / ref - 1) * 100, 1),
                        "risk_lot": round((ref - sl) * lot), "reward_lot": round((tgt - ref) * lot), "lot": lot,
                        "lot_cost": round(ref * lot), "score": best["score"], "max": best.get("max", 6), "need": need, "opp": opp,
                        "missing": [n for n, v in (best["an"].get("signals") or {}).items() if not v],
                        "block": best["block"], "chg": self._chg(und, cfg, now)})
        order = {"READY": 0, "BUILDING": 1, "WEAK": 2, "NONE": 3}
        out.sort(key=lambda i: (order[i["state"]], -(i.get("score") or 0)))
        return out

    # ------------------------------------------------------------------ sizing + risk
    def _lots(self, ref, lot, cc):
        if cc["sizing"] == "BUDGET":
            n = int(float(cc["budget"]) // (ref * lot)) if ref * lot > 0 else 0
            return min(n, int(cc["max_lots"]))
        return min(int(cc["lots"]), int(cc["max_lots"]))

    @staticmethod
    def _risk(entry, atr_abs, tick, cc):
        if cc["sl_mode"] == "ATR" and atr_abs > 0:
            slp = min(max(atr_abs * float(cc["sl_atr_mult"]) / entry * 100, float(cc["sl_min_pct"])), float(cc["sl_max_pct"]))
        else:
            slp = float(cc["sl_fixed_pct"])
        r = entry * slp / 100.0
        sl = round_tick(entry - r, tick, "down")
        tgt = round_tick(entry + float(cc["rr"]) * r, tick, "up") if cc["target_on"] else None
        return slp, round(r, 2), sl, tgt

    # ------------------------------------------------------------------ orders
    def _max_qty(self, und, lot, cc):
        o = cc.get("max_qty_per_order") or {}
        mq = int(o.get(und, contracts.und_info(und)[2]) or 0)
        return max(lot, (mq // lot) * lot) if mq else 0

    def _fill(self, side, p_like, qty, ref, cc, dry):
        """-> (filled_qty, avg_price, msg). DRY simulates a fill; LIVE places LIMIT orders and verifies them."""
        tick = p_like["tick"]
        if dry:
            slip = float(cc["slip_pct"]) / 100.0
            px = ref * (1 + slip) if side == "BUY" else ref * (1 - slip)
            return qty, round_tick(px, tick), "paper fill"
        total, value, msg = 0, 0.0, ""
        mq = self._max_qty(p_like["und"], p_like["lot"], cc)
        left = qty
        while left > 0:
            sl_qty = min(left, mq) if mq else left
            buf = float(cc["entry_buffer_pct"] if side == "BUY" else cc["exit_buffer_pct"]) / 100.0
            px = round_tick(ref * (1 + buf) if side == "BUY" else ref * (1 - buf), tick, "up" if side == "BUY" else "down")
            try:
                oid = self.kio.place_limit(p_like["exchange"], p_like["symbol"], side, sl_qty, px, p_like["product"])
            except Exception as e:                       # noqa: BLE001
                msg = "order rejected: %s" % e
                self.log("%s order failed %s: %s" % (side, p_like["symbol"], e), "err")
                break
            filled, avg, st = 0, 0.0, ""
            t_end = time.time() + float(cc["fill_wait_s"])
            while True:
                s = self.kio.order_status(oid)
                filled, avg, st = s["filled"], s["avg"], s["status"]
                if st in ("COMPLETE", "REJECTED", "CANCELLED") or time.time() >= t_end:
                    break
                time.sleep(0.7)
            if st != "COMPLETE":
                try:
                    if st not in ("REJECTED", "CANCELLED"):
                        self.kio.cancel(oid)
                except Exception as e:                   # noqa: BLE001
                    self.log("cancel failed %s: %s" % (oid, e), "warn")
                s = self.kio.order_status(oid)           # final fill after cancel
                filled, avg, st = s["filled"], s["avg"], s["status"]
                msg = "%s (%s)" % (st, s["msg"]) if s["msg"] else st
            if filled > 0:
                total += filled
                value += filled * avg
            if filled < sl_qty:
                break                                     # not fully filled - stop slicing
            left -= sl_qty
        return total, (round(value / total, 2) if total else 0.0), msg

    # ------------------------------------------------------------------ entry
    def _enter(self, r, cfg, now):
        cc, dry = self._cc_u(cfg, r["und"]), bool(cfg["dry_run"])
        ref = r["ask"] if r.get("ask") else r["ltp"]
        if r.get("lot_warn") and not dry and str(cfg["mcx"].get("lot_guard", "WARN")).upper() == "BLOCK_LIVE":   # optional strict mode
            self._notes[r["und"]] = "LIVE entry refused - " + r["lot_warn"]
            self.log("LIVE entry refused %s: %s" % (r["symbol"], r["lot_warn"]), "warn")
            return
        lots = self._lots(ref, r["lot"], cc)
        mov = float(cc.get("max_order_value", 0) or 0)
        if mov > 0 and lots >= 1 and ref * r["lot"] * lots > mov:
            lots = int(mov // (ref * r["lot"]))
            if lots < 1:
                self._notes[r["und"]] = "1 lot costs Rs %.0f - above the max order value Rs %.0f" % (ref * r["lot"], mov)
                return
        if lots < 1:
            self._notes[r["und"]] = "budget too small for 1 lot (%.0f)" % (ref * r["lot"])
            return
        qty = lots * r["lot"]
        cap = self._profit_cap(cc, now)
        if cap is not None and cap / qty < 2 * r["tick"]:
            self._notes[r["und"]] = "profit lock: today's booked profit allows a loss of only Rs %.0f (%d%%) - too tight for this trade, skipped" % (
                cap, float(cc["profit_lock_pct"]))
            return
        slip_pos = {"und": r["und"], "lot": r["lot"], "tick": r["tick"], "exchange": r["exchange"],
                    "symbol": r["symbol"], "product": cc["product"]}
        self.log("ENTRY %s %s qty %d (%d lot x %d) @~%.2f - %s" % (r["und"], r["symbol"], qty, lots, r["lot"], ref, r.get("why", "")), "trade")
        filled, avg, msg = self._fill("BUY", slip_pos, qty, ref, cc, dry)
        self.cool[r["und"]] = self.cool[r["symbol"]] = now + timedelta(minutes=int(cc["cooldown_min"]))
        if filled <= 0:
            self.log("Entry NOT filled %s: %s" % (r["symbol"], msg or "no fill"), "warn")
            return
        hero = cfg["mode"] == "HERO"
        if hero:
            slp, R, sl, tgt = self._hero_risk(avg, r["tick"], cfg["hero"])
            rr_used = None
        else:
            pl = self._plan(avg, r.get("atr", 0.0), r["tick"], cc, r.get("reach"))
            slp, R, sl, tgt, rr_used = pl["slp"], pl["R"], pl["sl"], pl["tgt"], pl["rr"]
        pid = "%s-%s" % (r["symbol"], now.strftime("%H%M%S"))
        pos = {"id": pid, "und": r["und"], "symbol": r["symbol"], "token": r["token"], "exchange": r["exchange"],
               "kind": r["kind"], "strike": r["strike"], "expiry": r["expiry"], "lot": r["lot"], "tick": r["tick"],
               "mode": "MCX" if contracts.is_mcx(r["und"]) else cfg["mode"], "qty": filled, "entry": avg, "entry_time": now.isoformat(timespec="seconds"),
               "sl": sl, "sl0": sl, "target": tgt, "r": R, "sl_pct": round(slp, 1), "peak": avg, "be": False, "trail": False,
               "dry": dry, "product": cc["product"], "ltp": avg, "why": r.get("why", ""), "exit_fail": 0, "ai": r.get("ai"),
               "lots": lots, "rr": rr_used, "target_mode": None if hero else str(cc.get("target_mode", "RR")).upper()}
        if hero:                                          # hero trades use their own breakeven / trail distances
            h = cfg["hero"]
            pos.update(be_r=float(h["be_r"]), trail_start_r=float(h["trail_start_r"]), trail_mult=float(h["trail_mult"]),
                       target_x=float(h["target_x"]))
        if cap is not None and not hero:                   # profit lock: the stop can never be wider than the allowed loss
            pos["loss_cap"] = round(cap, 2)
            sl_cap = round_tick(avg - cap / filled, r["tick"], "up")
            if sl_cap > pos["sl"]:
                pos["sl"] = pos["sl0"] = sl_cap
                pos["capped"] = True
                self.log("PROFIT LOCK %s: max loss Rs %.0f (%d%% of today's booked profit) -> SL %.2f" % (
                    r["symbol"], cap, float(cc["profit_lock_pct"]), sl_cap), "trade")
        self.positions[pid] = pos
        self._save_positions()
        if filled < qty:
            self.log("PARTIAL fill %d of %d - managing the filled part." % (filled, qty), "warn")
        self.log("FILLED %s %d @ %.2f | SL %.2f (-%.1f%%) | Target %s" % (
            r["symbol"], filled, avg, sl, slp, ("%.2f" % tgt) if tgt else "off"), "trade")

    # ------------------------------------------------------------------ position management
    def _manage_positions(self, cfg, now):
        for p in list(self.positions.values()):
            cc = self._eff(cfg, p.get("mode"))
            q = self.q.get("%s:%s" % (p["exchange"], p["symbol"]))
            ltp = float(q["last_price"]) if q and q.get("last_price") else 0.0
            force_t = cfg["pine"]["force_exit"] if p["mode"] == "PINE" else cc["force_exit"]
            g = grp(p.get("mode"))
            if ltp <= 0:
                if mins(now) >= hm(force_t):               # no price but time is up -> still try to leave
                    self._exit(p, "Force exit time (no live price)")
                continue
            p["ltp"] = ltp
            p["peak"] = max(p["peak"], ltp)
            if p.get("exit_fail", 0) >= 5:
                if int(now.second) % 10 == 0:
                    self._exit(p, "Retry exit")
                continue
            R, entry = p["r"], p["entry"]
            be_r = float(p.get("be_r", cc["be_r"]))
            tr_start, tr_mult = float(p.get("trail_start_r", cc["trail_start_r"])), float(p.get("trail_mult", cc["trail_mult"]))
            if not p["be"] and cc["be_on"] and ltp >= entry + be_r * R:
                p["be"] = True
                p["sl"] = max(p["sl"], round_tick(entry + p["tick"], p["tick"], "up"))
                self.log("%s +%.1fR -> SL moved to cost %.2f" % (p["symbol"], be_r, p["sl"]), "trade")
            if cc["trail_on"] and ltp >= entry + tr_start * R:
                if not p["trail"]:
                    p["trail"] = True
                    self.log("%s trailing started" % p["symbol"], "trade")
                new = round_tick(p["peak"] - tr_mult * R, p["tick"], "down")
                if new > p["sl"]:
                    p["sl"] = new
            reason = None
            pnl = (ltp - entry) * p["qty"]
            if ltp <= p["sl"]:
                reason = ("Profit-lock stop (max loss Rs %.0f)" % p["loss_cap"] if p.get("capped") else "Stop-loss hit") if p["sl"] <= p["sl0"] else ("Trailing stop" if p["trail"] else "Stop moved to cost hit")
            elif p["target"] and ltp >= p["target"]:
                reason = "Target hit"
            elif p["mode"] == "HERO" and self._hero_stale(cfg, p, ltp, now):
                reason = "No follow-through (%d min)" % int(cfg["hero"]["stale_exit_min"])
            elif float(cc["max_loss_trade"]) > 0 and pnl <= -float(cc["max_loss_trade"]):
                reason = "Max loss per trade"
            elif p.get("loss_cap") and pnl <= -float(p["loss_cap"]):
                reason = "Profit-lock stop (max loss Rs %.0f)" % p["loss_cap"]
            elif mins(now) >= hm(force_t):
                reason = "Force exit time %s" % force_t
            elif self._day_pnl(now, g) <= -abs(float(cc["daily_max_loss"])):
                reason = "Daily max loss reached"
                if self.running and grp(cfg["mode"]) == g:
                    self.running = False
                    self.log("Daily max loss reached - entries stopped.", "err")
            if reason:
                self._exit(p, reason, ltp)
        self._save_positions()

    def _exit(self, p, reason, ltp=None):
        cfg = config.load()
        cc = cfg["common"]
        q = self.q.get("%s:%s" % (p["exchange"], p["symbol"])) or {}
        ltp = ltp or float(q.get("last_price") or p["ltp"] or p["entry"])
        bid = ((q.get("depth") or {}).get("buy") or [{}])[0].get("price") or 0.0
        ref = min(ltp, bid) if bid > 0 else ltp
        if not p["dry"]:                                  # never SELL something that is no longer held (would open a short)
            try:
                net = sum(int(x.get("quantity", 0)) for x in self.kio.broker_positions() if x.get("tradingsymbol") == p["symbol"])
                if net <= 0:
                    self.log("%s is no longer held in Kite (closed outside the app?) - removing it, NO order sent." % p["symbol"], "warn")
                    self.positions.pop(p["id"], None)
                    self._save_positions()
                    return
                if net < p["qty"]:
                    self.log("%s: Kite shows only %d (app had %d) - exiting %d." % (p["symbol"], net, p["qty"], net), "warn")
                    p["qty"] = net
            except Exception as ex:                       # noqa: BLE001 - cannot verify: carry on with the exit
                self.log("Could not verify Kite position before exit: %s" % ex, "warn")
        self.log("EXIT %s qty %d (%s) ref %.2f" % (p["symbol"], p["qty"], reason, ref), "trade")
        slip = {"und": p["und"], "lot": p["lot"], "tick": p["tick"], "exchange": p["exchange"], "symbol": p["symbol"],
                "product": p["product"]}
        filled, avg, msg = self._fill("SELL", slip, p["qty"], ref, cc, p["dry"])
        if filled > 0:
            self._book(p, filled, avg, reason)
        if filled < p["qty"]:
            p["qty"] -= filled
            p["exit_fail"] = p.get("exit_fail", 0) + 1
            self.log("EXIT incomplete %s: %d left (%s)%s" % (p["symbol"], p["qty"], msg,
                     " - EXIT MANUALLY IN KITE IF THIS KEEPS FAILING" if p["exit_fail"] >= 3 else ""), "err")
        self._save_positions()

    def _book(self, p, qty, price, reason):
        pnl = round((price - p["entry"]) * qty, 2)
        tr = {"id": p["id"], "und": p["und"], "symbol": p["symbol"], "mode": p["mode"], "qty": qty, "entry": p["entry"],
              "exit": price, "pnl": pnl, "reason": reason, "entry_time": p["entry_time"],
              "exit_time": self.clock().isoformat(timespec="seconds"), "dry": p["dry"], "ai": p.get("ai")}
        self.trades.append(tr)
        self._save_trades()
        if qty >= p["qty"]:
            self.positions.pop(p["id"], None)
        self.log("CLOSED %s %d @ %.2f  P&L %+.2f  (%s)" % (p["symbol"], qty, price, pnl, reason), "trade")

    # ------------------------------------------------------------------ stats
    def _today_trades(self, now, g=None):
        d = now.date().isoformat()
        return [t for t in self.trades if str(t["exit_time"])[:10] == d and (g is None or grp(t.get("mode")) == g)]

    def _day_pnl(self, now, g=None):
        realized = sum(t["pnl"] for t in self._today_trades(now, g))
        unreal = sum((p["ltp"] - p["entry"]) * p["qty"] for p in self.positions.values()
                     if g is None or grp(p.get("mode")) == g)
        return realized + unreal

    def _trades_today(self, now, g=None):
        d = now.date().isoformat()
        ids = {t["id"] for t in self._today_trades(now, g)}           # a partly-filled exit makes 2 rows for 1 trade
        ids |= {p["id"] for p in self.positions.values()
                if p["entry_time"][:10] == d and (g is None or grp(p.get("mode")) == g)}
        return len(ids)

    # ------------------------------------------------------------------ API helpers
    def state(self):
        """Page snapshot. The engine thread holds the lock while it talks to Kite (can take seconds), so the page never
        waits for it: if the lock is busy we hand back the previous snapshot (marked stale) instead of freezing."""
        if not self.lock.acquire(timeout=0.25):
            if self._snap is not None:
                snap = dict(self._snap)
                snap["stale"] = True
                return snap
            self.lock.acquire()
        try:
            self._snap = self._state_locked()
            return self._snap
        finally:
            self.lock.release()

    def _state_locked(self):
        cfg = config.public()
        now = self.clock()
        pos = []
        for p in self.positions.values():
            d = dict(p)
            d["pnl"] = round((p["ltp"] - p["entry"]) * p["qty"], 2)
            d["pnl_pct"] = round((p["ltp"] / p["entry"] - 1) * 100, 2) if p["entry"] else 0
            pos.append(d)
        today = self._today_trades(now)
        return {"now": now.strftime("%Y-%m-%d %H:%M:%S"), "status": self.status, "running": self.running,
                "mode": cfg["mode"], "dry_run": cfg["dry_run"], "kite": self.kio.status(),
                "positions": pos, "cands": self.cands, "notes": self._notes,
                "spot": self.spot, "settings": cfg, "logs": list(self.logs)[-80:][::-1],
                "stats": {"trades": len(today), "realized": round(sum(t["pnl"] for t in today), 2),
                          "unrealized": round(sum(x["pnl"] for x in pos), 2),
                          "wins": sum(1 for t in today if t["pnl"] > 0), "losses": sum(1 for t in today if t["pnl"] <= 0)},
                "trades": today[::-1][:40], "ideas": self.ideas, "hero": self._hero_info,
                "ai": {"enabled": bool(cfg["ai"]["enabled"]), "model": cfg["ai"]["model"], "has_key": ai_gate.has_key(),
                       "min_confidence": cfg["ai"]["min_confidence"], "recent": list(self.ai_log)[-15:][::-1]},
                "profit_lock": {"pct": float(cfg["common"].get("profit_lock_pct", 0) or 0),
                                "booked": round(sum(t["pnl"] for t in self._today_trades(now)), 2),
                                "cap": (lambda c: None if c is None else round(c, 2))(self._profit_cap(cfg["common"], now))},
                "limits": {"trades": self._trades_today(now, grp(cfg["mode"])), "max_trades": int(cfg["common"]["max_trades_day"]),
                           "day_pnl": round(self._day_pnl(now, grp(cfg["mode"])), 2),
                           "max_loss": abs(float(cfg["common"]["daily_max_loss"])), "open": len(self.positions)}}

    def analyze_now(self):
        """One analysis pass with the current settings (works without pressing Start; never trades)."""
        with self.lock:
            cfg = config.load()
            now = self.clock()
            if not self.kio.connected():
                return {"ok": False, "error": "Kite login needed"}
            specs = self._specs(cfg)
            skeys = {u: self._spot_key(u, cfg, now) for u in sorted({s[0] for s in specs})}
            keys = [k for k in skeys.values() if k] + self._cand_keys
            self.q.update(self.kio.quote(keys))
            for u, k in skeys.items():
                sq = self.q.get(k) if k else None
                if sq and sq.get("last_price"):
                    self.spot[u] = float(sq["last_price"])
            if cfg["mode"] == "HERO":
                return self._hero_analyze(cfg, now)
            self._evaluate(cfg, specs, now, 0)
            self.q.update(self.kio.quote(self._cand_keys))
            rows = self._evaluate(cfg, specs, now, 60)   # 2nd pass: prices of freshly resolved contracts are in now
            need = sig.needed(self._eff(cfg))
            if cfg["mode"] == "PINE":
                self._pine_eval(cfg, rows, need)
            picks = []
            if cfg["mode"] != "PINE":
                by = collections.defaultdict(list)
                for r in rows:
                    by[r["und"]].append(r)
                picks = [b for b in (self._edge_pick(cl, need, self._mode_edge(cfg)) for cl in by.values()) if b]
            for r in rows:
                r["need"] = need
            self.cands = [{k: v for k, v in r.items() if k not in ("an", "raw_candles")} for r in rows]
            self._rows_full = rows
            self.ideas = self._make_ideas(cfg, rows, picks, need, now)
            return {"ok": True, "cands": self.cands, "ideas": self.ideas}

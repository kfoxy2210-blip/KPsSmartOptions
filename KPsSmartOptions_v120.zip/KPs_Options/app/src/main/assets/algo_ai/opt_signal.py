"""Option-PREMIUM analysis. Everything here looks only at the option's own price candles (not the index chart).

A premium that is trending up with momentum, volume and no chop is what we want to BUY - whether that is the CALL
or the PUT. So the same 7 checks are run on every candidate contract and "bullish" always means "this option's price is
rising".  Pure functions (no network) so they can be unit-tested.
"""
from datetime import time as dtime

STRICTNESS = {"Relaxed (3)": 3, "Normal (4)": 4, "Strict (5)": 5, "Very strict (6)": 6}
SIGNAL_NAMES = ["EMA trend up", "Price above EMA", "Above VWAP", "RSI momentum", "Breakout", "Not choppy", "Volume rising"]


def ema(vals, n):
    if not vals:
        return []
    k = 2.0 / (n + 1)
    out = [vals[0]]
    for v in vals[1:]:
        out.append(v * k + out[-1] * (1 - k))
    return out


def rsi(closes, n=14):
    if len(closes) < n + 1:
        return None
    gains = losses = 0.0
    for i in range(1, n + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / n, losses / n
    for i in range(n + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        ag = (ag * (n - 1) + max(d, 0.0)) / n
        al = (al * (n - 1) + max(-d, 0.0)) / n
    if al == 0:
        return 100.0
    return 100.0 - 100.0 / (1 + ag / al)


def atr(candles, n=14):
    """Wilder ATR of the premium (absolute rupees)."""
    if len(candles) < 2:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        c, p = candles[i], candles[i - 1]
        trs.append(max(c["h"] - c["l"], abs(c["h"] - p["c"]), abs(c["l"] - p["c"])))
    a = sum(trs[:n]) / min(n, len(trs))
    for tr in trs[n:]:
        a = (a * (n - 1) + tr) / n
    return a


def vwap(candles):
    """Session VWAP from the candles of the LAST candle's date; None if there is no volume."""
    if not candles:
        return None
    day = candles[-1]["t"].date()
    pv = vv = 0.0
    for c in candles:
        if c["t"].date() != day:
            continue
        pv += (c["h"] + c["l"] + c["c"]) / 3.0 * c["v"]
        vv += c["v"]
    return pv / vv if vv > 0 else None


def efficiency(closes, n=10):
    if len(closes) < n + 1:
        return 0.0
    seg = closes[-(n + 1):]
    path = sum(abs(seg[i] - seg[i - 1]) for i in range(1, len(seg)))
    return abs(seg[-1] - seg[0]) / path if path > 0 else 0.0


def analyze(candles, cfg):
    """7-signal premium score. candles: oldest first, the last one may still be forming."""
    need = max(int(cfg.get("ema_slow", 21)) + 2, 14)
    if len(candles) < need:
        return {"ok": False, "why": "only %d candles (need %d)" % (len(candles), need)}
    closes = [c["c"] for c in candles]
    ef = ema(closes, int(cfg.get("ema_fast", 9)))[-1]
    es = ema(closes, int(cfg.get("ema_slow", 21)))[-1]
    r = rsi(closes, int(cfg.get("rsi_len", 14)))
    vw = vwap(candles)
    er = efficiency(closes, int(cfg.get("er_len", 10)))
    n_bk = int(cfg.get("breakout_n", 6))
    prev_high = max(c["h"] for c in candles[-(n_bk + 1):-1]) if len(candles) > n_bk else None
    last = closes[-1]
    vols = [c["v"] for c in candles]
    recent, base = vols[-3:], vols[-13:-3]
    vol_ok = bool(base) and sum(base) > 0 and (sum(recent) / len(recent)) >= 1.2 * (sum(base) / len(base))
    rsi_max = float(cfg.get("rsi_max", 75))
    sig = [
        ef > es,
        last > ef,
        (vw is not None and last > vw),
        (r is not None and 52 <= r <= rsi_max),
        (prev_high is not None and last > prev_high),
        er >= float(cfg.get("min_er", 0.15)),
        vol_ok,
    ]
    strict_ok = bool(sig[0] and sig[1] and sig[4] and sig[5])  # EMA up + above EMA + fresh breakout + not choppy
    gate = str(cfg.get("trend_gate", "STRICT")).upper()
    if gate == "OFF":                                          # score alone decides
        trend_ok = True
    elif gate == "LOOSE":                                      # EMA up + above EMA + RSI momentum (no fresh-breakout / chop rule)
        trend_ok = bool(sig[0] and sig[1] and sig[3])
    else:
        trend_ok = strict_ok
    return {"ok": True, "trend_ok": trend_ok, "strict_ok": strict_ok, "gate": gate, "score": sum(sig), "max": len(sig), "signals": dict(zip(SIGNAL_NAMES, sig)),
            "ltp": last, "atr": atr(candles, int(cfg.get("atr_len", 14))), "ema_fast": ef, "ema_slow": es,
            "rsi": r, "vwap": vw, "er": er, "overstretched": bool(r is not None and r > rsi_max)}


def needed(cfg):
    return STRICTNESS.get(cfg.get("strictness", "Normal (4)"), 4)


# ------------------------------------------------------------------ Pine-style opening-range break on the premium
def orb(candles, minutes, interval_min):
    """Opening range of today's premium: first candle's open + high/low of the first `minutes` minutes."""
    if not candles:
        return None
    day = candles[-1]["t"].date()
    today = [c for c in candles if c["t"].date() == day]
    if not today or (today[0]["t"].hour, today[0]["t"].minute) != (9, 15):
        return None                                           # contract did not trade at the open
    rng = [c for c in today if (c["t"].hour * 60 + c["t"].minute) < 9 * 60 + 15 + max(int(minutes), interval_min)]
    return {"open": today[0]["o"], "hi": max(c["h"] for c in rng), "lo": min(c["l"] for c in rng)}


def pine_break(ltp, o, tick, cfg, prev_close=None):
    """True if the premium has moved beyond its 9:15 open by the configured % and ticks (and, optionally, a candle
    has CLOSED beyond that level)."""
    buf = float(cfg.get("break_pct", 3.0)) / 100.0
    lvl = max(o * (1 + buf), o + int(cfg.get("min_ticks", 1)) * tick)
    if ltp < lvl:
        return False, lvl
    if cfg.get("confirm_on_close", False):
        return (prev_close is not None and prev_close >= lvl), lvl
    return True, lvl


def in_window(now, start, end):
    """now: datetime; start/end 'HH:MM'."""
    def t(s):
        h, m = s.split(":")[:2]
        return dtime(int(h), int(m))
    return t(start) <= now.time() <= t(end)


# ------------------------------------------------------------------ is a 1:1.5 / 1:2 / 1:2.5 target actually possible?
def reach(candles, hold=8, lookback=40):
    """Evidence-based room to move: how far (in premium points) this option really went UP within `hold` candles,
    typically (70th percentile of such up-moves, measured from each candle's close) over the recent session.
    Returns None when there is not enough data (the filter then does not block)."""
    cs = [c for c in candles if c["t"].date() == candles[-1]["t"].date()] if candles else []
    if len(cs) < hold + 15:
        cs = candles[-(lookback + hold):] if candles else []
    legs = []
    for i in range(len(cs) - 1):
        fut = cs[i + 1:i + 1 + hold]
        if fut:
            legs.append(max(0.0, max(c["h"] for c in fut) - cs[i]["c"]))
    legs = legs[-lookback:]
    if len(legs) < 15:
        return None
    legs.sort()
    return legs[int(0.7 * (len(legs) - 1))]


def recent_low_gain_pct(candles, bars=10):
    """How far (%) the last price is above the lowest low of the last `bars` candles (used to avoid chasing)."""
    cs = candles[-bars:] if candles else []
    if not cs:
        return 0.0
    low = min(c["l"] for c in cs)
    return (candles[-1]["c"] / low - 1) * 100 if low > 0 else 0.0


# ------------------------------------------------------------------ HERO-ZERO (cheap expiry-day option that starts to run)
HERO_SIGNALS = ["Breakout", "Above EMA", "Above VWAP", "Volume surge", "Rising from low", "Higher lows"]


def hero_check(candles, cfg):
    """Is this cheap option starting to run? Uses only TODAY's candles of the option itself.
    Hard gates (all three needed): fresh breakout + above EMA9 + volume surge. Score = 6 checks. `overrun` = it already
    ran too far from the day's low (chasing the top of a spike)."""
    if not candles:
        return {"ok": False, "why": "no candles"}
    day = candles[-1]["t"].date()
    cs = [c for c in candles if c["t"].date() == day]
    if len(cs) < 8:
        return {"ok": False, "why": "only %d candles today (need 8)" % len(cs)}
    closes = [c["c"] for c in cs]
    last = closes[-1]
    n = max(int(cfg.get("breakout_n", 4)), 2)
    prev_high = max(c["h"] for c in cs[-(n + 1):-1])
    ef = ema(closes, 9)[-1]
    vw = vwap(cs)
    vols = [c["v"] for c in cs]
    recent, base = vols[-3:-1], vols[-13:-3]            # last two COMPLETED candles vs the 10 before them
    bavg = sum(base) / len(base) if base else 0.0
    surge = (sum(recent) / len(recent)) / bavg if bavg > 0 and recent else 0.0
    low = min(c["l"] for c in cs)
    gain = (last / low - 1) * 100 if low > 0 else 0.0
    higher = len(cs) >= 4 and cs[-2]["l"] >= cs[-4]["l"] and cs[-1]["l"] >= cs[-3]["l"]
    sig = [last > prev_high, last > ef, vw is not None and last > vw, surge >= float(cfg.get("min_surge", 1.5)),
           gain >= float(cfg.get("min_gain_pct", 15)), higher]
    return {"ok": True, "trend_ok": bool(sig[0] and sig[1] and sig[3]), "score": sum(sig), "max": len(sig),
            "signals": dict(zip(HERO_SIGNALS, sig)), "ltp": last, "gain_pct": round(gain, 1), "surge": round(surge, 2),
            "overrun": gain >= float(cfg.get("max_run_pct", 200)), "atr": atr(cs, 10), "ema_fast": ef, "vwap": vw,
            "rsi": rsi(closes, 9), "er": efficiency(closes, 6)}

"""Zerodha Kite layer for KP's Options: login, instruments, quotes, option candles, orders.

Keys / token are stored only in settings.json / kite_token.json next to this app (your own PC).
Every function that talks to Kite is rate-limited so the account is never throttled.
"""
import json
import os
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qs, urlparse

BASE = os.path.dirname(os.path.abspath(__file__))
SETTINGS = os.path.join(BASE, "settings.json")
TOKEN = os.path.join(BASE, "kite_token.json")


class KiteError(Exception):
    pass


_lock = threading.Lock()
_client = None
_inst = {}                      # exchange -> (date, rows)
_listener = None
_rl_lock = threading.Lock()
_last = {"hist": 0.0, "quote": 0.0, "order": 0.0}
_MIN_GAP = {"hist": 0.42, "quote": 1.05, "order": 0.12}   # hist <=2.5/s, quote 1/s, orders <=8/s


def ist_now():
    return datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=5, minutes=30)


def _read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _write(path, d):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _pace(kind):
    with _rl_lock:
        wait = _last[kind] + _MIN_GAP[kind] - time.time()
        if wait > 0:
            time.sleep(wait)
        _last[kind] = time.time()


# ------------------------------------------------------------------ keys / session
def get_keys():
    d = _read(SETTINGS)
    return d.get("kite_api_key", "").strip(), d.get("kite_api_secret", "").strip()


def save_keys(key, secret):
    d = _read(SETTINGS)
    changed = d.get("kite_api_key") != key.strip()
    d["kite_api_key"], d["kite_api_secret"] = key.strip(), secret.strip()
    _write(SETTINGS, d)
    if changed:
        disconnect()


def _token_fresh(ts):
    """Kite tokens expire around 06:00 IST every day."""
    shift = timedelta(hours=6)
    then = datetime.fromtimestamp(ts, timezone.utc).replace(tzinfo=None) + timedelta(hours=5, minutes=30)
    return (ist_now() - shift).date() == (then - shift).date()


def _saved_token():
    key, _ = get_keys()
    d = _read(TOKEN)
    if key and d.get("api_key") == key and d.get("access_token") and _token_fresh(d.get("ts", 0)):
        return d["access_token"]
    return None


def installed():
    try:
        import kiteconnect  # noqa: F401
        return True
    except ImportError:
        return False


def connected():
    return installed() and _saved_token() is not None


def status():
    key, secret = get_keys()
    return {"installed": installed(), "has_keys": bool(key and secret), "connected": connected(),
            "api_key_masked": (key[:3] + "***" + key[-2:]) if len(key) > 6 else ("***" if key else "")}


def _new_kite(key):
    try:
        from kiteconnect import KiteConnect
    except ImportError:
        raise KiteError("kiteconnect install nahi hai:  pip install kiteconnect")
    return KiteConnect(api_key=key)


def login_url():
    key, secret = get_keys()
    if not (key and secret):
        raise KiteError("Pehle API key aur secret save karo.")
    return _new_kite(key).login_url()


def complete_login(text):
    key, secret = get_keys()
    if not (key and secret):
        raise KiteError("Pehle API key aur secret save karo.")
    text = (text or "").strip()
    tok = None
    if "request_token" in text:
        tok = (parse_qs(urlparse(text).query).get("request_token") or [None])[0]
        if not tok:
            m = re.search(r"request_token=([A-Za-z0-9]+)", text)
            tok = m.group(1) if m else None
    else:
        tok = text
    if not tok:
        raise KiteError("request_token nahi mila. Login ke baad address bar ka poora URL paste karo.")
    try:
        sess = _new_kite(key).generate_session(tok, api_secret=secret)
    except Exception as e:                       # noqa: BLE001
        raise KiteError("Kite login fail: %s" % e)
    _write(TOKEN, {"api_key": key, "access_token": sess["access_token"], "ts": time.time()})
    global _client
    with _lock:
        _client = None
        _inst.clear()


def disconnect():
    global _client
    with _lock:
        _client = None
        _inst.clear()
    try:
        os.remove(TOKEN)
    except OSError:
        pass


def _kite():
    global _client
    with _lock:
        if _client is None:
            tok = _saved_token()
            if not tok:
                raise KiteError("Kite login nahi hai (token expire?). Dobara login karo.")
            key, _ = get_keys()
            k = _new_kite(key)
            k.set_access_token(tok)
            _client = k
        return _client


def _call(fn, *a, **kw):
    try:
        return fn(*a, **kw)
    except Exception as e:                       # noqa: BLE001
        if type(e).__name__ == "TokenException":
            disconnect()
            raise KiteError("Kite login expire ho gaya. Dobara login karo.")
        raise


def start_redirect_listener(port=5000, app_url="http://127.0.0.1:5090/"):
    """Catch Kite's redirect (127.0.0.1:5000/?request_token=...) and finish the login automatically."""
    global _listener
    from http.server import BaseHTTPRequestHandler, HTTPServer
    if _listener is not None:
        return True

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            tok = (parse_qs(urlparse(self.path).query).get("request_token") or [None])[0]
            if not tok:
                self.send_response(404)
                self.end_headers()
                return
            ok = True
            try:
                complete_login(tok)
                msg = "Kite connected! Ye tab band karke KP's Options par jao."
            except KiteError as e:
                ok = False
                msg = "Login fail: " + str(e)
            body = ('<html><meta http-equiv="refresh" content="2;url=%s"><body style="font:18px sans-serif;'
                    'background:#0e1116;color:#e6e9ee;padding:40px">%s</body></html>' % (app_url, msg)).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(body)
            if ok:
                threading.Thread(target=_stop_listener, daemon=True).start()

        def log_message(self, *a):
            pass

    try:
        srv = HTTPServer(("127.0.0.1", port), H)
    except OSError:
        return False
    _listener = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    t = threading.Timer(600, _stop_listener)
    t.daemon = True
    t.start()
    return True


def _stop_listener():
    global _listener
    srv, _listener = _listener, None
    if srv is not None:
        try:
            srv.shutdown()
            srv.server_close()
        except Exception:                        # noqa: BLE001
            pass


# ------------------------------------------------------------------ market data
def instruments(exchange):
    """Instrument rows (list of dicts) for NFO / BFO / NSE / BSE, cached for the day."""
    today = ist_now().date()
    with _lock:
        c = _inst.get(exchange)
        if c and c[0] == today:
            return c[1]
    rows = _call(_kite().instruments, exchange)
    with _lock:
        _inst[exchange] = (today, rows)
    return rows


def quote(keys):
    """keys like ['NFO:NIFTY25NOV24000CE', 'NSE:NIFTY 50'] -> {key: quote dict}. One call (max 500 keys)."""
    out = {}
    keys = list(dict.fromkeys(keys))
    for i in range(0, len(keys), 400):
        _pace("quote")
        out.update(_call(_kite().quote, *keys[i:i + 400]) or {})
    return out


def hist(token, frm, to, interval):
    """Candles [{t(naive IST datetime), o,h,l,c,v}] for an instrument token."""
    _pace("hist")
    rows = _call(_kite().historical_data, token, frm, to, interval)
    out = []
    for r in rows or []:
        t = r["date"]
        if getattr(t, "tzinfo", None) is not None:
            t = t.replace(tzinfo=None)           # Kite returns IST already
        out.append({"t": t, "o": float(r["open"]), "h": float(r["high"]), "l": float(r["low"]),
                    "c": float(r["close"]), "v": float(r.get("volume") or 0)})
    return out


# ------------------------------------------------------------------ orders
def place_limit(exchange, symbol, side, qty, price, product, tag="KPOPT"):
    _pace("order")
    k = _kite()
    return _call(k.place_order, variety=k.VARIETY_REGULAR, exchange=exchange, tradingsymbol=symbol,
                 transaction_type=k.TRANSACTION_TYPE_BUY if side == "BUY" else k.TRANSACTION_TYPE_SELL,
                 quantity=int(qty), product=product, order_type=k.ORDER_TYPE_LIMIT, price=float(price),
                 validity=k.VALIDITY_DAY, tag=tag)


def order_status(order_id):
    """-> {'status': 'COMPLETE'|'OPEN'|'REJECTED'|'CANCELLED'..., 'filled': int, 'avg': float, 'msg': str}"""
    _pace("order")
    h = _call(_kite().order_history, order_id) or []
    if not h:
        return {"status": "UNKNOWN", "filled": 0, "avg": 0.0, "msg": ""}
    last = h[-1]
    return {"status": str(last.get("status", "")).upper(), "filled": int(last.get("filled_quantity") or 0),
            "avg": float(last.get("average_price") or 0.0), "msg": str(last.get("status_message") or "")}


def cancel(order_id):
    _pace("order")
    k = _kite()
    return _call(k.cancel_order, variety=k.VARIETY_REGULAR, order_id=order_id)


def broker_positions():
    _pace("order")
    return (_call(_kite().positions) or {}).get("net", [])
